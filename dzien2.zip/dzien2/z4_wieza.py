"""Zadanie 2.4 - Chwytak buduje wieżę z klocków.

Uruchom:   uv run python dzien2/z4_wieza.py          (macOS: uv run mjpython dzien2/z4_wieza.py)
Szybko, bez okna:  uv run python dzien2/z4_wieza.py --bez-okna

Chwytak ma kamerę patrzącą w dół. Na klockach są markery ArUco (ID 0, 1, 2, ...).
Cel: zbuduj wieżę na zielonym polu (pozycja: g.tower_position).

Poziomy:
  1. Wykryj markery i wypisz pozycje klocków w układzie ŚWIATA.
  2. Podnieś jeden klocek i odłóż go na zielone pole.
  3. Zbuduj wieżę ze wszystkich klocków.
  *   Klocki w kolejności ID (0 na dole).
  **  Obrócone klocki (random_yaw=True) - obróć chwytak tak, żeby wieża była równa.
  *** Więcej klocków (n_blocks=5) - nie wszystkie widać z pozycji startowej!
"""

import math

import numpy as np

from moj_kod.transformacje import transform_point, yaw_from_transform
from moj_kod.wizja import detect_markers, draw_markers, marker_pose
from narzedzia.aruco import MUJOCO_FROM_OPENCV
from narzedzia.chwytak import HOME, GripperSim

g = GripperSim(n_blocks=3, random_yaw=False)

K = g.camera_matrix()  # parametry kamery (3x3)
T_gripper_camera = g.camera_in_gripper()  # gdzie jest kamera na chwytaku (4x4)
block = g.block_size  # bok klocka [m]

# ---------------------------------------------------------------- 1. Rozglądamy się
g.move_to(*HOME)
image = g.camera_image()
detections = detect_markers(image)
poses = {i: marker_pose(c, g.marker_size, K) for i, c in detections.items()}
g.show_image(draw_markers(image, detections, K, poses))
print("Widzę markery:", sorted(detections))

# TODO: dla każdego markera policz jego pozycję i obrót (yaw) w układzie ŚWIATA.
#   T_swiat_marker = T_swiat_chwytak @ T_chwytak_kamera @ (kamera MuJoCo <- kamera OpenCV) @ T_kamera_marker
#   g.gripper_pose()      -> T_swiat_chwytak
#   T_gripper_camera      -> T_chwytak_kamera
#   MUJOCO_FROM_OPENCV    -> zamiana konwencji kamery (OpenCV: z do przodu, y w dół; MuJoCo: z do tyłu, y w górę)
#   poses[i]              -> T_kamera_marker (z solvePnP)
blocks = {}  # {id: (x, y, yaw)}
T_world_gripper = g.gripper_pose()
for marker_id, T_camera_marker in poses.items():
    # TODO: TWÓJ KOD TUTAJ
    pass

for marker_id, (x, y, yaw) in sorted(blocks.items()):
    print(f"Klocek {marker_id}: x = {x:.3f}  y = {y:.3f}  yaw = {math.degrees(yaw):.0f}°")


# ---------------------------------------------------------------- 2-3. Budujemy wieżę
def nearest_equivalent(angle: float) -> float:
    """Klocek jest sześcianem - obrót o 90° wygląda tak samo. Wybierz najmniejszy obrót chwytaka."""
    return (angle + math.pi / 4) % (math.pi / 2) - math.pi / 4


tower_x, tower_y = g.tower_position
safe_z = 0.35  # na tej wysokości chwytak bezpiecznie przelatuje nad klockami

# TODO: dla każdego klocka: nad klocek -> w dół -> g.grab() -> w górę -> nad wieżę -> w dół -> g.release() -> w górę
#   Wskazówka: przyssawka musi dotknąć górnej ścianki klocka. Klocek leżący na stole ma górę na wysokości `block`.
#   Na której wysokości jest góra n-tego klocka w wieży?
# TODO: TWÓJ KOD TUTAJ
pass

g.move_to(*HOME)
g.finish()
