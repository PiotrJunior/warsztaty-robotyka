"""Wykrywanie markerów ArUco i wyznaczanie ich położenia względem kamery - DZIEŃ 2.

Używamy słownika DICT_4X4_50 (markery 4x4 pola, ID od 0 do 49).
"""

import cv2
import numpy as np

from moj_kod.transformacje import make_transform

ARUCO_DICT = cv2.aruco.getPredefinedDictionary(cv2.aruco.DICT_4X4_50)


def detect_markers(image) -> dict:
    """Znajduje markery na obrazie (RGB albo skala szarości).

    Zwraca słownik {id: corners}, gdzie corners to tablica 4x2 z pikselami rogów markera
    w kolejności: lewy-górny, prawy-górny, prawy-dolny, lewy-dolny.
    """
    # TODO: TWÓJ KOD TUTAJ
    return {}


def marker_pose(corners, marker_size: float, K, dist_coeffs=None) -> np.ndarray:
    """Położenie markera względem kamery: macierz 4x4 T_kamera_marker (konwencja OpenCV).

    Układ markera: środek w środku markera, x w prawo, y w górę (patrząc na marker), z "wychodzi" z markera.
    Kamera OpenCV: x w prawo, y w dół obrazu, z do przodu (tam, gdzie patrzy kamera).

    Wskazówki:
      - przygotuj 4 punkty 3D rogów markera w JEGO układzie (ta sama kolejność co corners!)
      - cv2.solvePnP(punkty_3d, corners, K, dist_coeffs, flags=cv2.SOLVEPNP_IPPE_SQUARE) -> ok, rvec, tvec
      - cv2.Rodrigues(rvec) zamienia rvec na macierz obrotu 3x3
    """
    if dist_coeffs is None:
        dist_coeffs = np.zeros(5)
    # TODO: TWÓJ KOD TUTAJ
    return np.eye(4)


def draw_markers(image, detections: dict, K=None, poses: dict | None = None, axis_length: float = 0.03) -> np.ndarray:
    """Rysuje wykryte markery (i ich osie, jeśli podasz poses = {id: T_kamera_marker}). Gotowe."""
    out = np.ascontiguousarray(image.copy())
    if out.ndim == 2:
        out = cv2.cvtColor(out, cv2.COLOR_GRAY2RGB)
    if detections:
        ids = np.array(list(detections.keys())).reshape(-1, 1)
        corners = [c.reshape(1, 4, 2).astype(np.float32) for c in detections.values()]
        cv2.aruco.drawDetectedMarkers(out, corners, ids)
    if poses and K is not None:
        for T in poses.values():
            rvec, _ = cv2.Rodrigues(T[:3, :3])
            cv2.drawFrameAxes(out, K, np.zeros(5), rvec, T[:3, 3], axis_length)
    return out
