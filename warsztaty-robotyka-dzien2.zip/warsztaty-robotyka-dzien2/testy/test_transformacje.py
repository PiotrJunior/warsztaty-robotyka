"""Testy macierzy transformacji.   Uruchom:  uv run python testy/test_transformacje.py"""

import math

import numpy as np
from _sprawdzarka import check, summary

from moj_kod.transformacje import invert_transform, make_transform, rotation_z, transform_point, yaw_from_transform

print("Test transformacji (moj_kod/transformacje.py)")

R90 = np.array([[0.0, -1.0, 0.0], [1.0, 0.0, 0.0], [0.0, 0.0, 1.0]])

check("make_transform składa R i t w macierz 4x4",
      lambda: np.allclose(make_transform(R90, [1, 2, 3]), [[0, -1, 0, 1], [1, 0, 0, 2], [0, 0, 1, 3], [0, 0, 0, 1]]),
      "zacznij od np.eye(4), wstaw R w T[:3, :3] i t w T[:3, 3]")
check("rotation_z(90°) obraca oś x na oś y",
      lambda: np.allclose(rotation_z(math.pi / 2), R90),
      "[[cos, -sin, 0], [sin, cos, 0], [0, 0, 1]] - kąt w radianach!")
check("transform_point: punkt (1, 0, 0) po obrocie o 90° i przesunięciu (1, 2, 3)",
      lambda: np.allclose(transform_point(make_transform(R90, [1, 2, 3]), [1, 0, 0]), [1, 3, 3]),
      "dopisz 1 na końcu punktu: [x, y, z, 1], pomnóż przez T i weź pierwsze 3 liczby")
check("invert_transform: T @ odwrotność(T) = jednostkowa",
      lambda: np.allclose(make_transform(rotation_z(0.7), [1, -2, 0.5]) @ invert_transform(make_transform(rotation_z(0.7), [1, -2, 0.5])), np.eye(4)),
      "odwrotność: obrót R.T, przesunięcie -R.T @ t")
check("yaw_from_transform odczytuje kąt obrotu",
      lambda: abs(yaw_from_transform(make_transform(rotation_z(2.0), [0, 0, 0])) - 2.0) < 1e-9,
      "math.atan2(T[1, 0], T[0, 0])")
check("składanie: T_a_c = T_a_b @ T_b_c",
      lambda: np.allclose(transform_point(make_transform(rotation_z(math.pi / 2), [1, 0, 0]) @ make_transform(np.eye(3), [1, 0, 0]), [0, 0, 0]), [1, 1, 0]))
summary()
