"""Wykrywanie markerów ArUco i wyznaczanie ich położenia względem kamery - DZIEŃ 2.

TEN PLIK JEST GOTOWY - nie musisz nic tu pisać, ale zajrzyj, jak działa:
    detect_markers(obraz)          -> {id: 4 rogi markera w pikselach}          (OpenCV szuka kwadratów i czyta bity)
    marker_pose(rogi, bok, K)      -> T_kamera_marker: gdzie jest marker względem kamery   (solvePnP)
    draw_markers(...)              -> obrazek z ramkami, numerami i osiami

Używamy słownika DICT_4X4_50 (markery 4x4 pola, ID od 0 do 49).

★ Eksperyment: w marker_pose() zamień kolejność dwóch rogów w object_points i uruchom dzien2/z3_kamera_laptopa.py.
  Co stało się z osiami markera? Dlaczego kolejność rogów musi się zgadzać z tą z detect_markers()?
"""

import cv2
import numpy as np

from moj_kod.transformacje import make_transform

ARUCO_DICT = cv2.aruco.getPredefinedDictionary(cv2.aruco.DICT_4X4_50)


def detect_markers(image) -> dict:
    """Znajduje markery na obrazie (RGB albo skala szarości).

    Zwraca słownik {id: corners}, gdzie corners to tablica 4x2 z pikselami rogów markera
    w kolejności: lewy-górny, prawy-górny, prawy-dolny, lewy-dolny.
    """
    gray = image if image.ndim == 2 else cv2.cvtColor(image, cv2.COLOR_RGB2GRAY)
    params = cv2.aruco.DetectorParameters()
    params.cornerRefinementMethod = cv2.aruco.CORNER_REFINE_SUBPIX  # (*) dokładniejsze rogi
    detector = cv2.aruco.ArucoDetector(ARUCO_DICT, params)
    corners, ids, _rejected = detector.detectMarkers(gray)
    if ids is None:
        return {}
    return {int(i): c.reshape(4, 2) for i, c in zip(ids.flatten(), corners)}


def marker_pose(corners, marker_size: float, K, dist_coeffs=None) -> np.ndarray:
    """Położenie markera względem kamery: macierz 4x4 T_kamera_marker (konwencja OpenCV).

    Układ markera: środek w środku markera, x w prawo, y w górę (patrząc na marker), z "wychodzi" z markera.
    Kamera OpenCV: x w prawo, y w dół obrazu, z do przodu (tam, gdzie patrzy kamera).

    Jak to działa:
      - znamy 4 rogi markera w JEGO układzie (3D, w metrach) i te same 4 rogi na obrazie (2D, w pikselach),
      - cv2.solvePnP szuka takiego położenia markera, żeby rzut rogów 3D trafił w rogi na obrazie,
      - cv2.Rodrigues zamienia obrót z solvePnP (rvec) na macierz obrotu 3x3.
    """
    if dist_coeffs is None:
        dist_coeffs = np.zeros(5)
    h = marker_size / 2.0
    # rogi w kolejności jak w detect_markers: lewy-górny, prawy-górny, prawy-dolny, lewy-dolny
    object_points = np.array([[-h, h, 0.0], [h, h, 0.0], [h, -h, 0.0], [-h, -h, 0.0]])
    ok, rvec, tvec = cv2.solvePnP(object_points, np.asarray(corners, dtype=np.float64), K, dist_coeffs, flags=cv2.SOLVEPNP_IPPE_SQUARE)
    R, _ = cv2.Rodrigues(rvec)
    return make_transform(R, tvec.flatten())


def draw_markers(image, detections: dict, K=None, poses: dict | None = None, axis_length: float = 0.03) -> np.ndarray:
    """Rysuje wykryte markery (i ich osie, jeśli podasz poses = {id: T_kamera_marker}). Gotowe."""
    out = np.ascontiguousarray(image.copy())
    if out.ndim == 2:
        out = cv2.cvtColor(out, cv2.COLOR_GRAY2RGB)
    if detections:
        ids = np.array(list(detections.keys())).reshape(-1, 1)
        corners = [c.reshape(1, 4, 2).astype(np.float32) for c in detections.values()]
        cv2.aruco.drawDetectedMarkers(out, corners, ids)
    if poses and K is not None:
        for T in poses.values():
            rvec, _ = cv2.Rodrigues(T[:3, :3])
            cv2.drawFrameAxes(out, K, np.zeros(5), rvec, T[:3, 3], axis_length)
    return out
