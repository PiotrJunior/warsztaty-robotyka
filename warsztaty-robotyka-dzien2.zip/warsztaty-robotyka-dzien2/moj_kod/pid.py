"""Regulator PID - DZIEŃ 1.

Uzupełnij miejsca oznaczone TODO. Sprawdź się testem:
    uv run python testy/test_pid.py
"""


class PID:
    def __init__(self, kp: float, ki: float, kd: float, dt: float, output_limits=(None, None)):
        """
        kp, ki, kd     - wzmocnienia członów P, I, D
        dt             - co ile sekund wywołujemy update() (krok symulacji)
        output_limits  - (min, max) wyjścia regulatora; None = brak ograniczenia
        """
        self.kp = kp
        self.ki = ki
        self.kd = kd
        self.dt = dt
        self.output_limits = output_limits
        self.reset()

    def reset(self) -> None:
        """Zeruje pamięć regulatora (całkę i poprzedni błąd)."""
        # TODO: przygotuj zmienne, które regulator musi pamiętać między wywołaniami
        self.integral = 0.0
        self.prev_error = None

    def update(self, target: float, measurement: float) -> float:
        """Oblicza sygnał sterujący na podstawie wartości zadanej i zmierzonej."""
        # TODO: policz błąd oraz człony P, I, D.
        #  - pochodna w pierwszym wywołaniu (gdy nie ma poprzedniego błędu) = 0
        #  - wynik ogranicz do output_limits (jeśli nie są None)
        error = target - measurement

        p = self.kp * error

        self.integral += error * self.dt
        i = self.ki * self.integral

        if self.prev_error is None:
            d = 0.0
        else:
            d = self.kd * (error - self.prev_error) / self.dt
        self.prev_error = error

        output = p + i + d

        low, high = self.output_limits
        if high is not None and output > high:
            output = high
            # anti-windup (zadanie *): nie zbieraj całki, gdy wyjście jest nasycone
            self.integral -= error * self.dt
        if low is not None and output < low:
            output = low
            self.integral -= error * self.dt
        return output
