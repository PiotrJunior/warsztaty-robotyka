"""Macierze transformacji 4x4 - DZIEŃ 2.   TEN PLIK JEST GOTOWY - nie musisz nic tu pisać.

Macierz T_a_b opisuje, gdzie jest układ "b" widziany z układu "a" (obrót + przesunięcie w jednym):

        | R  t |      R - obrót (3x3), kolumny = osie układu b zapisane w układzie a
T_a_b = |      |      t - położenie początku układu b w układzie a
        | 0  1 |

Nie trzeba umieć mnożyć macierzy. Wystarczy zasada DOMINA - indeksy w środku muszą się "skleić":

    T_a_c = T_a_b @ T_b_c          (czytaj: z a do b, a potem z b do c)
    T_b_a = invert_transform(T_a_b)   (ta sama strzałka, tylko w drugą stronę)

★ Wyzwanie dla chętnych: napisz własne invert_transform (wskazówki są w tej funkcji)
  i sprawdź testem:  uv run python testy/test_transformacje.py
"""

import math

import numpy as np


def make_transform(R, t) -> np.ndarray:
    """Buduje macierz 4x4 z obrotu R (3x3) i przesunięcia t (3)."""
    T = np.eye(4)
    T[:3, :3] = R
    T[:3, 3] = np.asarray(t).reshape(3)
    return T


def rotation_z(angle: float) -> np.ndarray:
    """Macierz obrotu 3x3 wokół osi z o kąt `angle` (w radianach)."""
    c, s = math.cos(angle), math.sin(angle)
    return np.array([[c, -s, 0.0], [s, c, 0.0], [0.0, 0.0, 1.0]])


def invert_transform(T) -> np.ndarray:
    """Odwrotność transformacji: z T_a_b robi T_b_a (strzałka w drugą stronę)."""
    # ★ WYZWANIE: zastąp np.linalg.inv własnym wzorem. Wskazówki:
    #   - odwrotnością obrotu R jest R.T (transpozycja),
    #   - skoro p_a = R @ p_b + t, to jak wyrazić p_b przez p_a?
    #   Sprawdź się:  uv run python testy/test_transformacje.py
    return np.linalg.inv(T)


def transform_point(T, p) -> np.ndarray:
    """Przelicza punkt p (3) z układu "b" do układu "a" za pomocą T_a_b."""
    return (T @ np.append(np.asarray(p, dtype=float), 1.0))[:3]


def yaw_from_transform(T) -> float:
    """Kąt obrotu wokół osi z (w radianach) - dokąd wskazuje oś x układu po zrzutowaniu na podłogę."""
    return math.atan2(T[1, 0], T[0, 0])
