"""Zadanie 2.2 - Wyścig przez bramki!

Uruchom:   uv run python dzien2/z2_bramki.py       (macOS: uv run mjpython dzien2/z2_bramki.py)
Szybciej (bez okna):  uv run python dzien2/z2_bramki.py --bez-okna

Przeleć przez 3 bramki (po kolei!) i wyląduj... to znaczy dolatuj do mety (biały krąg, x = -8).
Pozycje bramek są losowe przy każdym uruchomieniu: sim.gates[i]["center"] (i obrót: sim.gates[i]["yaw"]).

Poziomy:
  1. Bramki proste, bez wiatru.
  *  Wiatr:              wind=True
  ** Obrócone bramki:    rotated_gates=True  - trzeba wlecieć w bramkę na wprost, a nie po skosie!
  Konkurs: najkrótszy czas przelotu bez uderzeń (wypisuje się na końcu). Sprawdź 5 różnych losowań!
"""

import math

import numpy as np

from moj_kod.kontroler import DroneController
from narzedzia import DroneSim

sim = DroneSim(scene="bramki", duration=40, start_pos=(0, 0, 0.1), wind=False, rotated_gates=False)
ctrl = DroneController(sim.dt)

# TODO: zbuduj listę punktów trasy (waypoints).
#   Najprościej: start (0, 0, 1) -> środek każdej bramki -> meta (sim.final_target).
#   (**) Dla obróconej bramki dodaj punkt PRZED i ZA bramką, wzdłuż jej osi:
#        kierunek przelotu przez bramkę o kącie yaw (w stopniach) to (cos(yaw), sin(yaw), 0).
#        (Sam dron się nie obraca - leci "bokiem" albo "tyłem", dla drona to bez różnicy.)
waypoints = [np.array([0.0, 0.0, 1.0])]
# TODO: TWÓJ KOD TUTAJ
pass

current = 0
while sim.running():
    pos = sim.position()
    orientation = sim.orientation()

    # TODO: przejdź do następnego punktu, gdy dron jest wystarczająco blisko obecnego
    # TODO: TWÓJ KOD TUTAJ
    pass
    target = waypoints[current]

    thrust, roll_cmd, pitch_cmd, yaw_cmd = ctrl.control(target, pos, orientation)
    sim.step(thrust, roll_cmd, pitch_cmd, yaw_cmd)

    for wp in waypoints:
        sim.show_target(wp, color=(1, 1, 1, 0.25), radius=0.04)
    sim.show_target(target)
    sim.log("pozycja [m]", x=pos[0], y=pos[1], z=pos[2])

sim.finish()
