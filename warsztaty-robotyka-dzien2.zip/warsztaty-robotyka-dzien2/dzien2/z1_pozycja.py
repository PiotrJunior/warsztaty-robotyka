"""Zadanie 2.1 - Regulacja pozycji: dron leci tam, gdzie mu każemy.

Uruchom:   uv run python dzien2/z1_pozycja.py       (macOS: uv run mjpython dzien2/z1_pozycja.py)

Edytujesz:  moj_kod/kontroler.py  (pid_x, pid_y oraz metoda position)

Dron ma odwiedzić rogi kwadratu 2 x 2 m (co 5 sekund nowy cel).
Kroki:
  1. Uzupełnij position(): błąd w x -> pitch, błąd w y -> roll. Uważaj na znaki!
  2. Dobierz kp i kd. Patrz na wykres: czy dron dolatuje? Czy przelatuje za daleko?
  *  Włącz wiatr (wind=True). Czy przyda się człon I?
  ** Zmień MAX_TILT w moj_kod/kontroler.py na 10, a potem na 35. Jak zmienia się czas dolotu?
"""

from moj_kod.kontroler import DroneController
from narzedzia import DroneSim
from narzedzia.ocena import step_report

CORNERS = [(0, 0, 1), (1, 1, 1), (-1, 1, 1.5), (-1, -1, 1), (1, -1, 1.5), (0, 0, 1)]
HOLD = 5.0

sim = DroneSim(scene="pusta", duration=len(CORNERS) * HOLD, start_pos=(0, 0, 0.1), wind=False)
ctrl = DroneController(sim.dt)

while sim.running():
    target = CORNERS[min(int(sim.time / HOLD), len(CORNERS) - 1)]
    pos = sim.position()
    orientation = sim.orientation()

    thrust, roll_cmd, pitch_cmd, yaw_cmd = ctrl.control(target, pos, orientation)
    sim.step(thrust, roll_cmd, pitch_cmd, yaw_cmd)

    sim.show_target(target)
    sim.log("x [m]", cel=target[0], dron=pos[0])
    sim.log("y [m]", cel=target[1], dron=pos[1])
    sim.log("z [m]", cel=target[2], dron=pos[2])

sim.finish()
print("Wyniki (oś x):")
for k in range(1, len(CORNERS)):
    if CORNERS[k][0] != CORNERS[k - 1][0]:
        step_report(sim, "x [m]", "dron", target=CORNERS[k][0], t_from=k * HOLD, t_to=(k + 1) * HOLD, start=CORNERS[k - 1][0], band=0.1)
