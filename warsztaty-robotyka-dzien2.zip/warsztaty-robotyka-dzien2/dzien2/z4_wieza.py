"""Zadanie 2.4 - Chwytak buduje wieżę z klocków.

Uruchom:   uv run python dzien2/z4_wieza.py          (macOS: uv run mjpython dzien2/z4_wieza.py)
Szybko, bez okna:  uv run python dzien2/z4_wieza.py --bez-okna

Chwytak ma kamerę patrzącą w dół. Na klockach są markery ArUco (ID 0, 1, 2, ...).
Cel: zbuduj wieżę na zielonym polu (pozycja: g.tower_position).

Poziomy:
  1. Wykryj markery i wypisz pozycje klocków w układzie ŚWIATA.
  2. Podnieś jeden klocek i odłóż go na zielone pole.
  3. Zbuduj wieżę ze wszystkich klocków.
  *   Klocki w kolejności ID (0 na dole).
  **  Obrócone klocki (random_yaw=True) - obróć chwytak tak, żeby wieża była równa.
  *** Więcej klocków (n_blocks=5) - nie wszystkie widać z pozycji startowej!

Ściągawka - co potrafi chwytak g (wszystko w metrach i radianach, układ świata: z w górę, stół na z = 0):
  Ruch
    g.move_to(x, y, z, yaw=0.0)   jedź przyssawką do punktu (x, y, z) i obróć o yaw; czeka, aż dojedzie
                                   z = wysokość przyssawki nad stołem (klocek na stole ma górę na z = g.block_size)
    g.gripper_position()          gdzie jest teraz chwytak: [x, y, z, yaw]
    g.gripper_pose()              to samo jako macierz 4x4: T_swiat_chwytak
    g.wait(sekundy)               poczekaj (symulacja biegnie dalej)
    HOME                          pozycja startowa (0, 0, 0.75, 0) - stąd kamera widzi cały stół: g.move_to(*HOME)
  Magnes
    g.grab()                      włącz magnes: łapie klocek tuż pod przyssawką (max 2,5 cm niżej, 3 cm w bok);
                                   zwraca True, jeśli złapał, i False, jeśli nie
    g.release()                   wyłącz magnes (klocek spada / zostaje tam, gdzie go postawisz)
  Kamera (patrzy w dół, zamontowana na chwytaku)
    g.camera_image()              zdjęcie z kamery (obraz RGB)
    g.show_image(obraz)           pokaż obraz w oknie symulacji
    g.camera_matrix()             K - parametry kamery (do marker_pose)
    g.camera_in_gripper()         T_chwytak_kamera - gdzie kamera jest na chwytaku
  Liczby
    g.tower_position              (x, y) środka zielonego pola
    g.block_size                  bok klocka: 0.07 m        g.marker_size   bok markera: 0.05 m
  Koniec
    g.finish()                    ocenia wieżę i zamyka okno (zawsze na końcu)
"""

import math

import numpy as np

from moj_kod.transformacje import transform_point, yaw_from_transform
from moj_kod.wizja import detect_markers, draw_markers, marker_pose
from narzedzia.aruco import MUJOCO_FROM_OPENCV
from narzedzia.chwytak import HOME, GripperSim

g = GripperSim(n_blocks=3, random_yaw=False)

K = g.camera_matrix()  # parametry kamery (3x3)
T_gripper_camera = g.camera_in_gripper()  # gdzie jest kamera na chwytaku (4x4)
block = g.block_size  # bok klocka [m]

# ---------------------------------------------------------------- 1. Rozglądamy się
g.move_to(*HOME)
image = g.camera_image()
detections = detect_markers(image)
poses = {i: marker_pose(c, g.marker_size, K) for i, c in detections.items()}
g.show_image(draw_markers(image, detections, K, poses))
print("Widzę markery:", sorted(detections))

# TODO: dla każdego markera policz jego pozycję i obrót (yaw) w układzie ŚWIATA.
#   T_swiat_marker = T_swiat_chwytak @ T_chwytak_kamera @ (kamera MuJoCo <- kamera OpenCV) @ T_kamera_marker
#   g.gripper_pose()      -> T_swiat_chwytak
#   T_gripper_camera      -> T_chwytak_kamera
#   MUJOCO_FROM_OPENCV    -> zamiana konwencji kamery (OpenCV: z do przodu, y w dół; MuJoCo: z do tyłu, y w górę)
#   poses[i]              -> T_kamera_marker (z solvePnP)
blocks = {}  # {id: (x, y, yaw)}
T_world_gripper = g.gripper_pose()
for marker_id, T_camera_marker in poses.items():
    # TODO: TWÓJ KOD TUTAJ
    pass

for marker_id, (x, y, yaw) in sorted(blocks.items()):
    print(f"Klocek {marker_id}: x = {x:.3f}  y = {y:.3f}  yaw = {math.degrees(yaw):.0f}°")


# ---------------------------------------------------------------- 2-3. Budujemy wieżę
def nearest_equivalent(angle: float) -> float:
    """Klocek jest sześcianem - obrót o 90° wygląda tak samo. Wybierz najmniejszy obrót chwytaka."""
    return (angle + math.pi / 4) % (math.pi / 2) - math.pi / 4


tower_x, tower_y = g.tower_position
safe_z = 0.35  # na tej wysokości chwytak bezpiecznie przelatuje nad klockami

# TODO: dla każdego klocka: nad klocek -> w dół -> g.grab() -> w górę -> nad wieżę -> w dół -> g.release() -> w górę
#   Wskazówka: przyssawka musi dotknąć górnej ścianki klocka. Klocek leżący na stole ma górę na wysokości `block`.
#   Na której wysokości jest góra n-tego klocka w wieży?
# TODO: TWÓJ KOD TUTAJ
pass

g.move_to(*HOME)
g.finish()
