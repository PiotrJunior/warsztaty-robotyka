"""Zadanie 2.3 - Markery ArUco w prawdziwej kamerze (kamera laptopa).

Uruchom:   uv run python dzien2/z3_kamera_laptopa.py      (także na macOS - tu NIE trzeba mjpython)
Zakończ:   klawisz q w oknie z obrazem.

Potrzebujesz wydrukowanych markerów (materialy/markery_do_druku.pdf) albo markera na ekranie telefonu.

Kod wykrywania markerów jest gotowy (moj_kod/wizja.py) - tu bawimy się kamerą.

Kroki:
  1. Uruchom i pokaż marker kamerze: pojawi się ramka, numer ID, osie markera i odległość od kamery.
     Poruszaj markerem: przybliż, oddal, obróć. Jak zmieniają się x, y, z?
  2. Zmierz MARKER_SIZE swojego wydruku (bok czarnego kwadratu, bez białej ramki) i wpisz niżej.
  3. Zmierz linijką odległość markera od kamery. Zgadza się?
  *  Nie znamy dokładnie kamery laptopa - zakładamy jej kąt widzenia (FOV_DEG).
     Zmieniaj FOV_DEG, aż odległość z kamery będzie zgadzać się z linijką. Właśnie skalibrowałeś/aś kamerę!
  ** Pokaż dwa markery naraz i policz odległość MIĘDZY nimi (użyj transformacji!).
  *** Eksperyment z kolejnością rogów - opis na górze moj_kod/wizja.py.
"""

import math

import cv2
import numpy as np

from moj_kod.wizja import detect_markers, draw_markers, marker_pose

MARKER_SIZE = 0.05  # [m] bok czarnego kwadratu - ZMIERZ swój wydruk!
FOV_DEG = 60.0  # zakładany poziomy kąt widzenia kamery laptopa
CAMERA_INDEX = 0  # jeśli nie działa, spróbuj 1


def camera_matrix(width: int, height: int, fov_deg: float) -> np.ndarray:
    f = (width / 2) / math.tan(math.radians(fov_deg) / 2)
    return np.array([[f, 0, width / 2], [0, f, height / 2], [0, 0, 1]])


cap = cv2.VideoCapture(CAMERA_INDEX)
if not cap.isOpened():
    raise SystemExit("Nie mogę otworzyć kamery. Sprawdź CAMERA_INDEX i uprawnienia do kamery (macOS: Ustawienia -> Prywatność -> Kamera -> Terminal).")

print("Naciśnij q, żeby zakończyć.")
while True:
    ok, frame_bgr = cap.read()
    if not ok:
        break
    frame = cv2.cvtColor(frame_bgr, cv2.COLOR_BGR2RGB)
    h, w = frame.shape[:2]
    K = camera_matrix(w, h, FOV_DEG)

    detections = detect_markers(frame)
    poses = {i: marker_pose(c, MARKER_SIZE, K) for i, c in detections.items()}
    out = draw_markers(frame, detections, K, poses, axis_length=MARKER_SIZE / 2)

    for k, (marker_id, T) in enumerate(sorted(poses.items())):
        distance = np.linalg.norm(T[:3, 3])
        text = f"ID {marker_id}: {distance * 100:.1f} cm   (x={T[0, 3] * 100:+.0f} y={T[1, 3] * 100:+.0f} z={T[2, 3] * 100:.0f})"
        cv2.putText(out, text, (10, 30 + 30 * k), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 0), 2)

    cv2.imshow("ArUco - q konczy", cv2.cvtColor(out, cv2.COLOR_RGB2BGR))
    if cv2.waitKey(1) & 0xFF == ord("q"):
        break

cap.release()
cv2.destroyAllWindows()
