"""Okno symulacji (viewer MuJoCo) + wykresy na żywo, napisy, obrazy i znaczniki 3D.

Tego pliku NIE musisz edytować.
"""

from __future__ import annotations

import sys
import time
from collections import deque

import mujoco
import numpy as np

HEADLESS_FLAG = "--bez-okna"

# Kolory linii na wykresach (RGB 0..1)
LINE_COLORS = [
    (1.0, 0.35, 0.35),
    (0.35, 0.8, 1.0),
    (0.45, 1.0, 0.45),
    (1.0, 0.85, 0.3),
    (0.9, 0.5, 1.0),
    (1.0, 1.0, 1.0),
]


_PL = str.maketrans("ąćęłńóśźżĄĆĘŁŃÓŚŹŻ°²", "acelnoszzACELNOSZZ 2")


def ascii_text(text: str) -> str:
    """MuJoCo potrafi wyświetlić tylko znaki ASCII - zamieniamy polskie litery na łacińskie."""
    return str(text).translate(_PL).encode("ascii", "replace").decode("ascii")


def headless_requested() -> bool:
    """Czy uruchomiono skrypt z flagą --bez-okna (szybko, bez okna)."""
    return HEADLESS_FLAG in sys.argv


def open_viewer(model: mujoco.MjModel, data: mujoco.MjData, camera: str | None = None):
    """Otwiera okno MuJoCo. Na macOS skrypt musi być uruchomiony przez `mjpython`."""
    from mujoco import viewer

    try:
        handle = viewer.launch_passive(model, data, show_left_ui=False, show_right_ui=False)
    except RuntimeError as exc:
        if "mjpython" in str(exc):
            script = sys.argv[0]
            print("\n" + "=" * 70)
            print("Na macOS okno symulacji wymaga uruchomienia przez mjpython:")
            print(f"    uv run mjpython {script}")
            print("(albo bez okna: uv run python " + script + " " + HEADLESS_FLAG + ")")
            print("=" * 70 + "\n")
            sys.exit(1)
        raise
    if camera is not None:
        handle.cam.type = mujoco.mjtCamera.mjCAMERA_FIXED
        handle.cam.fixedcamid = model.camera(camera).id
    return handle


class LivePlots:
    """Wykresy rysowane na żywo w oknie MuJoCo (ostatnie `window` sekund)."""

    def __init__(self, window: float = 6.0, max_figures: int = 3):
        self.window = window
        self.max_figures = max_figures
        self.series: dict[str, dict[str, deque]] = {}
        self.figures: dict[str, mujoco.MjvFigure] = {}

    def add(self, fig_name: str, t: float, values: dict[str, float]) -> None:
        if fig_name not in self.series:
            if len(self.series) >= self.max_figures:
                return
            self.series[fig_name] = {}
            self.figures[fig_name] = self._new_figure(fig_name)
        fig_series = self.series[fig_name]
        for name, value in values.items():
            if name not in fig_series:
                if len(fig_series) >= len(LINE_COLORS):
                    continue
                fig_series[name] = deque(maxlen=mujoco.mjMAXLINEPNT - 1)
            fig_series[name].append((t, float(value)))

    @staticmethod
    def _new_figure(title: str) -> mujoco.MjvFigure:
        fig = mujoco.MjvFigure()
        mujoco.mjv_defaultFigure(fig)
        fig.title = ascii_text(title)
        fig.flg_legend = 1
        fig.flg_extend = 1
        fig.gridsize = [4, 4]
        fig.figurergba[3] = 0.6
        fig.panergba[3] = 0.6
        fig.xformat = "%.0f"
        fig.yformat = "%.2f"
        fig.legendrgba[3] = 0.3
        return fig

    def render(self, handle) -> None:
        if not self.figures:
            return
        vp = handle.viewport
        width = max(int(vp.width * 0.32), 260) if vp is not None else 400
        height = max(int(vp.height * 0.28), 160) if vp is not None else 220
        items = []
        for k, (fig_name, fig) in enumerate(self.figures.items()):
            for i, (name, pts) in enumerate(self.series[fig_name].items()):
                if not pts:
                    continue
                t_last = pts[-1][0]
                arr = np.array([p for p in pts if p[0] >= t_last - self.window])
                n = len(arr)
                fig.linename[i] = ascii_text(name)
                fig.linergb[i] = LINE_COLORS[i]
                fig.linepnt[i] = n
                fig.linedata[i, 0 : 2 * n : 2] = arr[:, 0]
                fig.linedata[i, 1 : 2 * n : 2] = arr[:, 1]
            rect = mujoco.MjrRect(0, k * height, width, height)
            items.append((rect, fig))
        handle.set_figures(items)


class SceneMarkers:
    """Kolorowe kulki/strzałki rysowane w scenie (np. cel drona). Nie biorą udziału w fizyce."""

    def __init__(self):
        self.spheres: list[tuple[np.ndarray, float, tuple]] = []

    def clear(self):
        self.spheres = []

    def sphere(self, pos, radius=0.05, rgba=(0.2, 1.0, 0.2, 0.5)):
        self.spheres.append((np.asarray(pos, dtype=float), radius, rgba))

    def render(self, handle) -> None:
        scn = handle.user_scn
        scn.ngeom = 0
        for pos, radius, rgba in self.spheres:
            if scn.ngeom >= scn.maxgeom:
                break
            mujoco.mjv_initGeom(
                scn.geoms[scn.ngeom],
                type=mujoco.mjtGeom.mjGEOM_SPHERE,
                size=[radius, 0, 0],
                pos=pos,
                mat=np.eye(3).flatten(),
                rgba=np.asarray(rgba, dtype=np.float32),
            )
            scn.ngeom += 1


class Window:
    """Wspólna obsługa okna: synchronizacja w czasie rzeczywistym + nakładki."""

    def __init__(self, model, data, camera: str | None = None, speed: float = 1.0, headless: bool | None = None):
        self.model = model
        self.data = data
        self.speed = speed
        self.headless = headless_requested() if headless is None else headless
        self.handle = None if self.headless else open_viewer(model, data, camera)
        self.plots = LivePlots()
        self.markers = SceneMarkers()
        self.texts: list[tuple[str, str]] = []
        self.image: np.ndarray | None = None
        self._wall_start = time.time()
        self._sim_start = data.time
        self._last_overlay = 0.0

    def is_open(self) -> bool:
        return self.headless or self.handle.is_running()

    def sync(self, force_overlay: bool = False) -> None:
        if self.headless:
            return
        now = time.time()
        # nakładki odświeżamy ~20 razy na sekundę, żeby nie spowalniać symulacji
        if force_overlay or now - self._last_overlay > 0.05:
            self._last_overlay = now
            with self.handle.lock():
                self.markers.render(self.handle)
            self.plots.render(self.handle)
            if self.texts:
                self.handle.set_texts(
                    [
                        (mujoco.mjtFontScale.mjFONTSCALE_150, mujoco.mjtGridPos.mjGRID_TOPLEFT, ascii_text("\n".join(a for a, _ in self.texts)), ascii_text("\n".join(b for _, b in self.texts)))
                    ]
                )
            if self.image is not None:
                vp = self.handle.viewport
                h, w = self.image.shape[:2]
                scale = min(0.35 * vp.width / w, 0.45 * vp.height / h) if vp is not None else 0.5
                ih, iw = max(int(h * scale), 1), max(int(w * scale), 1)
                small = _resize_nearest(self.image, ih, iw)
                left = (vp.width - iw) if vp is not None else 0
                bottom = (vp.height - ih) if vp is not None else 0
                self.handle.set_images([(mujoco.MjrRect(left, bottom, iw, ih), small)])
        self.handle.sync()
        # czekamy, żeby symulacja szła w (mniej więcej) rzeczywistym tempie
        sim_elapsed = (self.data.time - self._sim_start) / self.speed
        wall_elapsed = time.time() - self._wall_start
        if sim_elapsed > wall_elapsed:
            time.sleep(sim_elapsed - wall_elapsed)

    def close(self) -> None:
        if self.handle is not None:
            try:
                self.handle.close()
            except Exception:
                pass
            self.handle = None


def _resize_nearest(img: np.ndarray, h: int, w: int) -> np.ndarray:
    ys = (np.arange(h) * img.shape[0] / h).astype(int)
    xs = (np.arange(w) * img.shape[1] / w).astype(int)
    out = img[ys][:, xs]
    if out.ndim == 2:
        out = np.stack([out] * 3, axis=-1)
    return np.ascontiguousarray(out[:, :, :3], dtype=np.uint8)
