"""Generuje PDF A4 z markerami ArUco do wydrukowania (skala 100%, bez dopasowania do strony!).

    uv run python -m narzedzia.drukuj_markery
"""

from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt

from narzedzia.aruco import marker_image

CM = 1 / 2.54  # cale


def main(out: Path | None = None) -> Path:
    out = out or Path(__file__).resolve().parent.parent / "materialy" / "markery_do_druku.pdf"
    out.parent.mkdir(exist_ok=True)
    W, H = 21.0, 29.7
    fig = plt.figure(figsize=(W * CM, H * CM))
    ax = fig.add_axes([0, 0, 1, 1])
    ax.set_xlim(0, W)
    ax.set_ylim(0, H)
    ax.axis("off")

    def put(marker_id, x, y, size):
        """size = bok czarnego kwadratu [cm]; obrazek ma dodatkowo białą ramkę 1 pole."""
        img = marker_image(marker_id, pixels_per_cell=50)
        full = size * 8 / 6
        ax.imshow(img, cmap="gray", vmin=0, vmax=255, extent=(x, x + full, y, y + full), interpolation="nearest")
        ax.add_patch(plt.Rectangle((x, y), full, full, fill=False, lw=0.3, ls=":", color="0.6"))
        ax.text(x + full / 2, y - 0.4, f"ID {marker_id}  -  bok {size:g} cm", ha="center", va="top", fontsize=8)

    ax.text(W / 2, H - 1.0, "Markery ArUco (DICT_4X4_50) - drukuj w skali 100%", ha="center", fontsize=12, weight="bold")
    ax.text(W / 2, H - 1.6, "Zmierz linijką bok CZARNEGO kwadratu i wpisz go w programie (MARKER_SIZE).", ha="center", fontsize=9)
    put(0, 1.5, 15.5, 8.0)
    put(1, 13.0, 21.0, 5.0)
    put(2, 13.0, 13.5, 5.0)
    put(3, 1.5, 2.0, 5.0)
    put(4, 8.5, 2.0, 5.0)
    put(5, 15.8, 6.5, 3.0)
    put(6, 15.8, 1.5, 3.0)
    fig.savefig(out)
    plt.close(fig)
    print(f"Zapisano: {out}")
    return out


if __name__ == "__main__":
    main()
