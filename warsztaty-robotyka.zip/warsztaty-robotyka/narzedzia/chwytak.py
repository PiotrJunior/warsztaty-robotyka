"""Symulator latającego chwytaka z kamerą i magnesem (DZIEŃ 2).

Tego pliku NIE musisz edytować.

    g = GripperSim()
    g.move_to(x, y, z, yaw)        # jedzie chwytakiem do punktu (czeka, aż dojedzie)
    img = g.camera_image()          # zdjęcie z kamery chwytaka (RGB)
    g.grab()                        # włącza magnes - łapie klocek tuż pod przyssawką
    g.release()                     # wyłącza magnes
    g.finish()                      # ocenia wieżę, zamyka okno
"""

from __future__ import annotations

import math
import sys
from pathlib import Path

import mujoco
import numpy as np

from . import aruco
from .okno import Window

ASSETS = Path(__file__).resolve().parent.parent / "assets"

BLOCK_HALF = 0.035  # klocek to sześcian 7 x 7 x 7 cm
MARKER_SIZE = 0.05  # bok czarnego kwadratu markera [m]
GRAB_RADIUS = 0.03  # magnes łapie klocek, jeśli środek jego górnej ścianki jest bliżej niż 3 cm (w poziomie)
GRAB_HEIGHT = 0.025  # ... i nie dalej niż 2.5 cm pod przyssawką
TOWER_XY = np.array([0.35, -0.25])
HOME = (0.0, 0.0, 0.75, 0.0)


class GripperSim:
    def __init__(
        self,
        n_blocks: int = 3,
        random_yaw: bool = False,
        seed: int | None = None,
        model_file: str | Path | None = None,
        speed: float = 1.0,
        move_speed: float = 0.4,
        camera_size: tuple[int, int] = (720, 960),
        headless: bool | None = None,
    ):
        self.rng = np.random.default_rng(seed)
        self.n_blocks = n_blocks
        self.move_speed = move_speed
        self.camera_size = camera_size
        self.tower_position = TOWER_XY.copy()
        self.block_size = 2 * BLOCK_HALF
        self.marker_size = MARKER_SIZE

        spec = mujoco.MjSpec.from_file(str(model_file or ASSETS / "scena_chwytak.xml"))
        self.block_ids = list(range(n_blocks))
        self._true_blocks = self._place_blocks(spec, n_blocks, random_yaw)

        self.model = spec.compile()
        self.data = mujoco.MjData(self.model)
        self.dt = self.model.opt.timestep
        self.camera_name = "gripper_camera"
        self._renderer = mujoco.Renderer(self.model, camera_size[0], camera_size[1])
        self._gripper_id = self.model.body("gripper").id
        self._block_body = {i: self.model.body(f"block{i}").id for i in self.block_ids}
        self._weld = {i: self.model.equality(f"magnet{i}").id for i in self.block_ids}
        self.holding: int | None = None

        self._set_target(*HOME)
        self.data.qpos[self._qadr("gx")] = HOME[0]
        self.data.qpos[self._qadr("gy")] = HOME[1]
        self.data.qpos[self._qadr("gz")] = HOME[2]
        mujoco.mj_forward(self.model, self.data)

        self.window = Window(self.model, self.data, speed=speed, headless=headless)
        self.title = Path(sys.argv[0]).stem
        self._closed = False
        self.wait(0.5)  # klocki opadają na stół

    # ------------------------------------------------------------------ scena
    def _place_blocks(self, spec, n, random_yaw):
        placed = []
        # ciała, które już leżą w scenie (np. klocki toy_* z Twojego modelu) - nie kładziemy na nich nowych klocków
        obstacles = [np.array(b.pos[:2]) for b in spec.worldbody.bodies if b.name != "gripper"]
        colors = [(0.9, 0.3, 0.2, 1), (0.2, 0.5, 0.9, 1), (0.95, 0.8, 0.2, 1), (0.3, 0.8, 0.4, 1), (0.8, 0.4, 0.9, 1), (0.9, 0.55, 0.2, 1)]
        tries = 0
        while len(placed) < n:
            tries += 1
            if tries > 10000:
                raise RuntimeError("Nie udało się rozmieścić klocków")
            xy = np.array([self.rng.uniform(-0.35, 0.2), self.rng.uniform(-0.15, 0.35)])
            if np.linalg.norm(xy - TOWER_XY) < 0.2 or any(np.linalg.norm(xy - p) < 0.14 for p in [q[0] for q in placed] + obstacles):
                continue
            yaw = float(self.rng.uniform(-math.pi, math.pi)) if random_yaw else 0.0
            placed.append((xy, yaw))
        for i, (xy, yaw) in enumerate(placed):
            body = spec.worldbody.add_body(name=f"block{i}", pos=[xy[0], xy[1], BLOCK_HALF + 0.001], quat=[math.cos(yaw / 2), 0, 0, math.sin(yaw / 2)])
            body.add_freejoint()
            body.add_geom(type=mujoco.mjtGeom.mjGEOM_BOX, size=[BLOCK_HALF] * 3, rgba=colors[i % len(colors)], mass=0.05, friction=[1.0, 0.01, 0.001])
            aruco.add_marker_sticker(spec, body, i, MARKER_SIZE, pos=(0, 0, BLOCK_HALF + 0.0005))
            eq = spec.add_equality(name=f"magnet{i}", type=mujoco.mjtEq.mjEQ_WELD, name1="gripper", name2=f"block{i}", active=False)
            eq.objtype = mujoco.mjtObj.mjOBJ_BODY
            eq.solref = [0.01, 1]
        return placed

    def _qadr(self, joint: str) -> int:
        return self.model.jnt_qposadr[self.model.joint(joint).id]

    def _set_target(self, x, y, z, yaw):
        self.data.ctrl[:4] = [x, y, z, yaw]  # ax, ay, az, ayaw (palce, jeśli są, zostają otwarte)

    # ------------------------------------------------------------------ ruch
    def gripper_position(self) -> np.ndarray:
        """Aktualna pozycja przyssawki [x, y, z] i obrót yaw [radiany] - z czujników przegubów."""
        return np.array([self.data.sensor(n).data[0] for n in ("sx", "sy", "sz", "syaw")])

    def gripper_pose(self) -> np.ndarray:
        """Położenie chwytaka w świecie jako macierz 4x4: T_swiat_chwytak."""
        x, y, z, yaw = self.gripper_position()
        T = np.eye(4)
        c, s = math.cos(yaw), math.sin(yaw)
        T[:3, :3] = [[c, -s, 0], [s, c, 0], [0, 0, 1]]
        T[:3, 3] = [x, y, z]
        return T

    def camera_in_gripper(self) -> np.ndarray:
        """Położenie kamery w układzie chwytaka: T_chwytak_kamera (kamera w konwencji MuJoCo).

        To samo możesz odczytać z pliku XML (pos i xyaxes kamery "gripper_camera")."""
        return aruco.camera_pose_in_body(self.model, self.camera_name)

    def move_to(self, x: float, y: float, z: float, yaw: float = 0.0, timeout: float = 8.0) -> bool:
        """Przesuwa chwytak do (x, y, z) i obraca do kąta yaw [radiany]. Czeka, aż dojedzie."""
        start = self.data.ctrl[:4].copy()
        goal = np.array([x, y, z, yaw], dtype=float)
        lo, hi = self.model.actuator_ctrlrange[:4, 0], self.model.actuator_ctrlrange[:4, 1]
        if np.any(goal < lo) or np.any(goal > hi):
            print(f"Uwaga: cel {np.round(goal, 3)} jest poza zasięgiem chwytaka - przycinam.")
            goal = np.clip(goal, lo, hi)
        dist = max(np.linalg.norm(goal[:3] - start[:3]), abs(goal[3] - start[3]) * 0.1)
        duration = max(dist / self.move_speed, 0.2)
        t0 = self.data.time
        while self.window.is_open():
            a = min((self.data.time - t0) / duration, 1.0)
            a = 0.5 - 0.5 * math.cos(math.pi * a)  # łagodny start i hamowanie
            self._set_target(*(start + a * (goal - start)))
            self._step()
            if self.data.time - t0 >= duration and np.linalg.norm(self.gripper_position()[:3] - goal[:3]) < 0.003:
                return True
            if self.data.time - t0 > duration + timeout:
                print("Uwaga: chwytak nie dojechał do celu (coś go blokuje?)")
                return False
        return False

    def wait(self, seconds: float) -> None:
        t0 = self.data.time
        while self.window.is_open() and self.data.time - t0 < seconds:
            self._step()

    def _step(self) -> None:
        mujoco.mj_step(self.model, self.data)
        if not self.window.headless:
            x, y, z, yaw = self.gripper_position()
            self.window.texts = [("czas", f"{self.data.time:5.1f} s"), ("chwytak", f"x={x:.3f} y={y:.3f} z={z:.3f} yaw={math.degrees(yaw):.0f}°"), ("magnes", "WŁ" if self.holding is not None else "wył")]
            # okno odświeżamy co ~1/60 s czasu symulacji
            if int(self.data.time / self.dt) % 8 == 0:
                self.window.sync()

    # ------------------------------------------------------------------ magnes
    def grab(self) -> bool:
        """Włącza magnes. Łapie klocek, którego górna ścianka jest tuż pod przyssawką."""
        if self.holding is not None:
            print("Magnes już trzyma klocek!")
            return True
        suction = self.data.site("suction").xpos
        best, best_d = None, None
        for i, bid in self._block_body.items():
            top = self.data.xpos[bid] + self.data.xmat[bid].reshape(3, 3) @ np.array([0, 0, BLOCK_HALF])
            d_xy = np.linalg.norm(top[:2] - suction[:2])
            d_z = suction[2] - top[2]
            if d_xy < GRAB_RADIUS and -0.005 < d_z < GRAB_HEIGHT and (best_d is None or d_xy < best_d):
                best, best_d = i, d_xy
        if best is None:
            print("Magnes: pod przyssawką nie ma klocka :(")
            return False
        # klocek "przyciąga się" do środka przyssawki, zachowując swój obrót
        bid = self._block_body[best]
        eq = self._weld[best]
        R_g = self.data.xmat[self._gripper_id].reshape(3, 3)
        R_b = self.data.xmat[bid].reshape(3, 3)
        R_rel = R_g.T @ R_b
        q_rel = np.zeros(4)
        mujoco.mju_mat2Quat(q_rel, R_rel.flatten())
        # eq_data (weld): anchor[3], relpos[3], relquat[4], torquescale
        self.model.eq_data[eq, 0:3] = [0, 0, 0]
        self.model.eq_data[eq, 3:6] = [0, 0, -BLOCK_HALF - 0.001]
        self.model.eq_data[eq, 6:10] = q_rel
        self.model.eq_data[eq, 10] = 1.0
        self.data.eq_active[eq] = 1
        self.holding = best
        self.wait(0.2)
        return True

    def release(self) -> None:
        """Wyłącza magnes."""
        if self.holding is not None:
            self.data.eq_active[self._weld[self.holding]] = 0
            self.holding = None
        self.wait(0.3)

    # ------------------------------------------------------------------ kamera
    def camera_image(self) -> np.ndarray:
        """Zdjęcie z kamery chwytaka (RGB, 720 x 960)."""
        self._renderer.update_scene(self.data, camera=self.camera_name)
        return self._renderer.render().copy()

    def camera_matrix(self) -> np.ndarray:
        return aruco.camera_matrix(self.model, self.camera_name, *self.camera_size)

    def show_image(self, image: np.ndarray) -> None:
        self.window.image = image
        self.window.sync(force_overlay=True)

    # ------------------------------------------------------------------ ocena
    def true_block_positions(self) -> dict[int, np.ndarray]:
        """Prawdziwe pozycje klocków - TYLKO do sprawdzania, nie do rozwiązywania zadania!"""
        return {i: self.data.xpos[bid].copy() for i, bid in self._block_body.items()}

    def tower_height(self) -> tuple[int, list[int]]:
        """Ile klocków stoi w wieży (licząc od dołu) i jakie mają ID."""
        stack = []
        for level in range(self.n_blocks):
            z_expected = BLOCK_HALF + level * 2 * BLOCK_HALF
            found = None
            for i, p in self.true_block_positions().items():
                if np.linalg.norm(p[:2] - self.tower_position) < 0.03 and abs(p[2] - z_expected) < 0.01:
                    found = i
            if found is None:
                break
            stack.append(found)
        return len(stack), stack

    def finish(self) -> int:
        if self._closed:
            return 0
        if self.holding is not None:
            self.release()
        self.wait(1.5)
        height, ids = self.tower_height()
        print("-" * 50)
        if height == 0:
            print("Wieża: brak klocków na zielonym polu.")
        else:
            print(f"Wieża: {height} klocki/ów (ID od dołu: {ids})")
            if height == self.n_blocks:
                print("BRAWO! Wszystkie klocki w wieży!" + ("  I to po kolei!" if ids == sorted(ids) else ""))
        self.window.close()
        self._renderer.close()
        self._closed = True
        return height
