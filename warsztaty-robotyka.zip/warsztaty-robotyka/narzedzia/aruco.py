"""Markery ArUco: generowanie obrazków, dodawanie ich do scen MuJoCo, parametry kamer.

Tego pliku NIE musisz edytować.
"""

from __future__ import annotations

import math

import cv2
import mujoco
import numpy as np

# Słownik markerów używany na całych warsztatach: 4x4 pola, 50 różnych ID.
ARUCO_DICT_ID = cv2.aruco.DICT_4X4_50


def aruco_dictionary():
    return cv2.aruco.getPredefinedDictionary(ARUCO_DICT_ID)


def marker_image(marker_id: int, pixels_per_cell: int = 40, border_cells: int = 1) -> np.ndarray:
    """Obrazek markera (skala szarości) z białą ramką dookoła.

    Marker 4x4 ma 6x6 pól (4x4 danych + czarna obwódka). Biała ramka jest potrzebna,
    żeby detektor odróżnił marker od tła.
    """
    inner = cv2.aruco.generateImageMarker(aruco_dictionary(), marker_id, 6 * pixels_per_cell)
    size = (6 + 2 * border_cells) * pixels_per_cell
    img = np.full((size, size), 255, dtype=np.uint8)
    o = border_cells * pixels_per_cell
    img[o : o + 6 * pixels_per_cell, o : o + 6 * pixels_per_cell] = inner
    return img


def add_marker_texture(spec: mujoco.MjSpec, marker_id: int) -> str:
    """Dodaje do sceny materiał z markerem o podanym ID. Zwraca nazwę materiału."""
    name = f"aruco_{marker_id}"
    if any(m.name == name for m in spec.materials):
        return name
    img = marker_image(marker_id)
    rgb = np.ascontiguousarray(np.stack([img] * 3, axis=-1))
    tex = spec.add_texture(name=name)
    tex.type = mujoco.mjtTexture.mjTEXTURE_2D
    tex.width = rgb.shape[1]
    tex.height = rgb.shape[0]
    tex.nchannel = 3
    tex.data = rgb.tobytes()
    mat = spec.add_material(name=name)
    mat.textures[mujoco.mjtTextureRole.mjTEXROLE_RGB] = name
    return name


def add_marker_sticker(spec, body, marker_id: int, marker_size: float, pos=(0, 0, 0), name: str | None = None):
    """Przykleja płaską naklejkę z markerem do ciała `body` (górna ścianka naklejki = marker).

    `marker_size` to długość boku CZARNEGO kwadratu markera (bez białej ramki) w metrach.
    Naklejka jest nieco większa, bo ma białą ramkę (1 pole z każdej strony).
    """
    material = add_marker_texture(spec, marker_id)
    half = marker_size / 2 * (8 / 6)  # 6 pól markera + 2 pola ramki
    return body.add_geom(
        name=name,
        type=mujoco.mjtGeom.mjGEOM_BOX,
        size=[half, half, 0.0005],
        pos=list(pos),
        material=material,
        contype=0,
        conaffinity=0,
        mass=0,
    )


def camera_matrix(model: mujoco.MjModel, camera: str, height: int, width: int) -> np.ndarray:
    """Macierz kamery K (model otworkowy) dla kamery MuJoCo o zadanej rozdzielczości."""
    fovy = model.cam_fovy[model.camera(camera).id]
    f = (height / 2.0) / math.tan(math.radians(fovy) / 2.0)
    return np.array([[f, 0.0, width / 2.0], [0.0, f, height / 2.0], [0.0, 0.0, 1.0]])


# Kamera w MuJoCo patrzy wzdłuż -z (oś y w górę obrazu), a w OpenCV wzdłuż +z (oś y w dół obrazu).
# Ta macierz przelicza punkty z układu kamery OpenCV do układu kamery MuJoCo:
#   p_mujoco = MUJOCO_FROM_OPENCV @ p_opencv
MUJOCO_FROM_OPENCV = np.array(
    [
        [1.0, 0.0, 0.0, 0.0],
        [0.0, -1.0, 0.0, 0.0],
        [0.0, 0.0, -1.0, 0.0],
        [0.0, 0.0, 0.0, 1.0],
    ]
)


def camera_pose_in_body(model: mujoco.MjModel, camera: str) -> np.ndarray:
    """Pozycja kamery względem ciała, do którego jest przymocowana (macierz 4x4, układ MuJoCo)."""
    cam_id = model.camera(camera).id
    T = np.eye(4)
    q = model.cam_quat[cam_id]
    mat = np.zeros(9)
    mujoco.mju_quat2Mat(mat, q)
    T[:3, :3] = mat.reshape(3, 3)
    T[:3, 3] = model.cam_pos[cam_id]
    return T
