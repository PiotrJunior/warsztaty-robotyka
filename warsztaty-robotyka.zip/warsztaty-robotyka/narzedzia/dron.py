"""Symulator drona Skydio X2 dla warsztatów.

Tego pliku NIE musisz edytować - ale możesz go czytać :)

Najważniejsze funkcje:
    sim = DroneSim(scene="pusta")       # tworzy scenę i otwiera okno
    while sim.running():                 # pętla sterowania, 100 razy na sekundę
        pos = sim.position()             # [x, y, z] w metrach (GPS)
        roll, pitch, yaw = sim.orientation()   # kąty w stopniach (IMU)
        sim.step(thrust, roll=..., pitch=..., yaw=...)
    sim.finish()                         # zamyka okno, zapisuje wykres

Konwencje sterowania (sim.step):
    thrust  - całkowity ciąg wszystkich 4 śmigieł [N]; dron waży 1.325 kg
    roll    - dodatnia wartość przechyla drona tak, że roll rośnie (lewa/prawa)
    pitch   - dodatnia wartość pochyla drona tak, że pitch rośnie (przód/tył)
    yaw     - dodatnia wartość obraca drona tak, że yaw rośnie (w lewo, patrząc z góry)
  roll/pitch/yaw to różnica ciągu między śmigłami [N].

Układ współrzędnych świata: z w górę. Przy yaw = 0:
    dodatni pitch  -> dron przyspiesza w kierunku +x
    dodatni roll   -> dron przyspiesza w kierunku -y
"""

from __future__ import annotations

import math
import sys
from pathlib import Path

import mujoco
import numpy as np
from scipy.spatial.transform import Rotation

from . import aruco
from .okno import Window
from .wykresy import Recorder

ASSETS = Path(__file__).resolve().parent.parent / "assets"
GRAVITY = 9.81
MAX_ROTOR_THRUST = 13.0  # [N] na jedno śmigło

GATE_HALF_OPENING = 0.6  # połowa szerokości otworu bramki [m]
GATE_COLORS = [(1, 0.2, 0.2, 1), (0.2, 1, 0.2, 1), (0.3, 0.4, 1, 1), (1, 1, 0.2, 1), (1, 0.4, 1, 1)]


class DroneSim:
    def __init__(
        self,
        scene: str = "pusta",
        duration: float = 20.0,
        start_pos=(0.0, 0.0, 0.1),
        start_yaw: float = 0.0,
        wind: bool = False,
        kicks: bool = False,
        rotated_gates: bool = False,
        gps: bool = True,
        camera: str | None = None,
        camera_fps: float = 20.0,
        camera_size: tuple[int, int] = (480, 640),
        image_noise: float = 0.0,
        frame_drop: float = 0.0,
        moving_platform: bool = False,
        vertical_only: bool = False,
        seed: int | None = None,
        speed: float = 1.0,
        view: str = "track",
        title: str | None = None,
        headless: bool | None = None,
    ):
        self.rng = np.random.default_rng(seed)
        self.scene = scene
        self.duration = duration
        self.wind_enabled = wind
        self.kicks_enabled = kicks
        self.gps = gps
        self.title = title or Path(sys.argv[0]).stem
        self.gates: list[dict] = []
        self.marker_poses: dict[int, np.ndarray] = {}
        self.final_target: np.ndarray | None = None
        self.moving_platform = moving_platform
        self.vertical_only = vertical_only  # dron jeździ tylko w górę i w dół (obrót i ruch w bok zablokowane)

        spec = mujoco.MjSpec.from_file(str(ASSETS / "scena_dron.xml"))
        if scene == "bramki":
            self._add_gates(spec, rotated_gates)
        elif scene == "markery":
            self._add_marker_carpet(spec)
        elif scene != "pusta":
            raise ValueError(f"Nieznana scena: {scene!r} (dostępne: pusta, bramki, markery)")
        if moving_platform:
            self._add_platform(spec)

        self.model = spec.compile()
        self.data = mujoco.MjData(self.model)
        self.dt = self.model.opt.timestep
        self.mass = float(self.model.body_subtreemass[self.model.body("x2").id])

        q = Rotation.from_euler("z", start_yaw, degrees=True).as_quat()  # x, y, z, w
        self.data.qpos[0:3] = start_pos
        self.data.qpos[3:7] = [q[3], q[0], q[1], q[2]]
        mujoco.mj_forward(self.model, self.data)
        self._update_platform()
        self._locked_qpos = self.data.qpos[[0, 1, 3, 4, 5, 6]].copy()

        self._drone_id = self.model.body("x2").id
        self._drone_geoms = {g for g in range(self.model.ngeom) if self.model.geom_bodyid[g] == self._drone_id}
        self._gate_geoms = {g for g in range(self.model.ngeom) if self.model.body(self.model.geom_bodyid[g]).name.startswith("gate")}

        # kamera
        self.camera = camera
        self.camera_size = camera_size
        self.camera_period = 1.0 / camera_fps
        self.image_noise = image_noise
        self.frame_drop = frame_drop
        self._renderer = mujoco.Renderer(self.model, camera_size[0], camera_size[1]) if camera else None
        self._next_frame_time = 0.0

        # zaburzenia
        self._wind = np.zeros(4)
        self._kick_until = -1.0
        self._next_kick = 2.0
        self._kick_torque = np.zeros(3)
        self._kick_active = False

        # stan misji
        self.collisions = 0
        self._in_collision = False
        self.crashed = False
        self.finished = False
        self.finish_time: float | None = None
        self._prev_local = None
        self._next_gate = 0

        self.recorder = Recorder()
        self.window = Window(self.model, self.data, camera=view if view in ("track",) else None, speed=speed, headless=headless)
        self._last_cmd = (0.0, 0.0, 0.0, 0.0)
        self._targets: list[np.ndarray] = []

    # ------------------------------------------------------------------ budowa scen
    def _add_gates(self, spec, rotated: bool) -> None:
        for i, x in enumerate([-2.0, -4.0, -6.0]):
            y = float(self.rng.uniform(-0.6, 0.6))
            z = float(self.rng.uniform(0.9, 1.5))
            yaw = float(self.rng.uniform(-40, 40)) if rotated else 0.0
            q = Rotation.from_euler("z", yaw, degrees=True).as_quat()
            body = spec.worldbody.add_body(name=f"gate{i}", pos=[x, y, z], quat=[q[3], q[0], q[1], q[2]])
            rgba = GATE_COLORS[i % len(GATE_COLORS)]
            h = GATE_HALF_OPENING
            for pos, size in [
                ([0, -h - 0.05, 0], [0.05, 0.05, h + 0.1]),
                ([0, h + 0.05, 0], [0.05, 0.05, h + 0.1]),
                ([0, 0, h + 0.05], [0.05, h + 0.1, 0.05]),
                ([0, 0, -h - 0.05], [0.05, h + 0.1, 0.05]),
            ]:
                body.add_geom(type=mujoco.mjtGeom.mjGEOM_BOX, pos=pos, size=size, rgba=rgba)
            # słupek pod bramką (tylko wizualnie)
            body.add_geom(type=mujoco.mjtGeom.mjGEOM_CYLINDER, pos=[0, 0, -(z + h) / 2 - 0.05], size=[0.03, (z - h) / 2, 0], rgba=(0.5, 0.5, 0.5, 1), contype=0, conaffinity=0)
            self.gates.append({"index": i, "center": np.array([x, y, z]), "yaw": yaw, "passed": False})
        self.final_target = np.array([-8.0, 0.0, 1.0])
        spec.worldbody.add_geom(type=mujoco.mjtGeom.mjGEOM_CYLINDER, pos=[-8, 0, 0.005], size=[0.3, 0.005, 0], rgba=(1, 1, 1, 0.8), contype=0, conaffinity=0)

    def _add_marker_carpet(self, spec) -> None:
        """Dywan markerów na podłodze: ID 0..8, siatka 3x3 co 1.5 m, bok markera 0.4 m."""
        size = 0.4
        k = 0
        for iy, y in enumerate([1.5, 0.0, -1.5]):
            for ix, x in enumerate([-1.5, 0.0, 1.5]):
                body = spec.worldbody.add_body(name=f"marker{k}", pos=[x, y, 0.001])
                aruco.add_marker_sticker(spec, body, k, size)
                T = np.eye(4)
                T[:3, 3] = [x, y, 0.0015]
                self.marker_poses[k] = T
                k += 1
        self.marker_size = size

    def _add_platform(self, spec) -> None:
        # platforma to ciężkie ciało na dwóch przegubach przesuwnych, pchane przez aktuatory pozycji
        # (dzięki temu tarcie "wiezie" drona, który na niej wyląduje)
        body = spec.worldbody.add_body(name="platform", pos=[0, 0, 0.052])
        body.add_joint(name="platform_x", type=mujoco.mjtJoint.mjJNT_SLIDE, axis=[1, 0, 0])
        body.add_joint(name="platform_y", type=mujoco.mjtJoint.mjJNT_SLIDE, axis=[0, 1, 0])
        body.add_geom(type=mujoco.mjtGeom.mjGEOM_BOX, size=[0.4, 0.4, 0.05], rgba=(0.9, 0.6, 0.1, 1), mass=30.0, friction=[1.5, 0.01, 0.001])
        for j in ("platform_x", "platform_y"):
            act = spec.add_actuator(name=f"{j}_act", target=j, trntype=mujoco.mjtTrn.mjTRN_JOINT)
            act.set_to_position(kp=20000, kv=2000)
        aruco.add_marker_sticker(spec, body, 20, 0.5, pos=(0, 0, 0.051))
        self.platform_marker_id = 20
        self.platform_marker_size = 0.5

    def _update_platform(self) -> None:
        if not self.moving_platform:
            return
        t = self.data.time
        # powolny ruch po "ósemce"
        x = 1.2 * math.sin(0.25 * t)
        y = 0.8 * math.sin(0.5 * t)
        self.data.ctrl[4:6] = [x, y]

    # ------------------------------------------------------------------ czujniki
    def position(self) -> np.ndarray:
        """Pozycja drona [x, y, z] w metrach (GPS)."""
        if not self.gps:
            raise RuntimeError("W tym zadaniu dron nie ma GPS! Pozycję trzeba wyznaczyć z kamery.")
        return self.data.body("x2").xpos.copy()

    def velocity(self) -> np.ndarray:
        """Prędkość drona [vx, vy, vz] w m/s (GPS)."""
        if not self.gps:
            raise RuntimeError("W tym zadaniu dron nie ma GPS! Prędkość trzeba oszacować (np. filtrem Kalmana).")
        return self.data.qvel[0:3].copy()

    def orientation(self) -> np.ndarray:
        """Kąty [roll, pitch, yaw] w stopniach (z czujnika IMU)."""
        q = self.data.sensor("body_quat").data
        return Rotation.from_quat([q[1], q[2], q[3], q[0]]).as_euler("xyz", degrees=True)

    def rotation_matrix(self) -> np.ndarray:
        """Orientacja drona jako macierz obrotu 3x3 (z czujnika IMU)."""
        q = self.data.sensor("body_quat").data
        return Rotation.from_quat([q[1], q[2], q[3], q[0]]).as_matrix()

    def angular_velocity(self) -> np.ndarray:
        """Prędkość obrotu [wokół x, wokół y, wokół z] w stopniach/s (żyroskop, układ drona)."""
        return np.degrees(self.data.sensor("body_gyro").data.copy())

    def true_position(self) -> np.ndarray:
        """Prawdziwa pozycja - TYLKO do wykresów i porównań, nie do sterowania!"""
        return self.data.body("x2").xpos.copy()

    def platform_position(self) -> np.ndarray:
        """Prawdziwa pozycja platformy - TYLKO do wykresów i porównań."""
        return self.data.body("platform").xpos.copy()

    @property
    def time(self) -> float:
        return float(self.data.time)

    # ------------------------------------------------------------------ kamera
    def camera_image(self) -> np.ndarray | None:
        """Zwraca nową klatkę z kamery (RGB) albo None, jeśli w tym kroku nie ma nowej klatki."""
        if self._renderer is None:
            raise RuntimeError("Ta symulacja nie ma kamery. Utwórz DroneSim(..., camera='down_camera').")
        if self.data.time + 1e-9 < self._next_frame_time:
            return None
        self._next_frame_time += self.camera_period
        if self.frame_drop > 0 and self.rng.uniform() < self.frame_drop:
            return None
        self._renderer.update_scene(self.data, camera=self.camera)
        img = self._renderer.render().copy()
        if self.image_noise > 0:
            noise = self.rng.normal(0, self.image_noise, img.shape)
            img = np.clip(img.astype(np.float32) + noise, 0, 255).astype(np.uint8)
        return img

    def camera_matrix(self) -> np.ndarray:
        """Macierz kamery K (3x3)."""
        return aruco.camera_matrix(self.model, self.camera, *self.camera_size)

    def camera_in_drone(self) -> np.ndarray:
        """Położenie kamery w układzie drona: macierz 4x4 T_dron_kamera (kamera w konwencji MuJoCo)."""
        return aruco.camera_pose_in_body(self.model, self.camera)

    def show_image(self, image: np.ndarray) -> None:
        """Pokazuje obraz (np. z narysowanymi markerami) w rogu okna symulacji."""
        self.window.image = image

    # ------------------------------------------------------------------ wizualizacja i wykresy
    def log(self, figure: str, **values: float) -> None:
        """Dodaje punkty do wykresu, np. sim.log("wysokość", cel=1.0, dron=z)."""
        t = self.time
        self.recorder.add(figure, t, values)
        if not self.window.headless:
            self.window.plots.add(figure, t, values)

    def show_target(self, pos, color=(0.2, 1.0, 0.2, 0.5), radius=0.06) -> None:
        """Rysuje w scenie kulkę w miejscu `pos` (np. cel drona)."""
        self._targets.append((np.asarray(pos, dtype=float), color, radius))

    # ------------------------------------------------------------------ krok symulacji
    def running(self) -> bool:
        if self.finished and self.time - (self.finish_time or 0) > 1.0:
            return False
        return self.window.is_open() and self.time < self.duration

    def step(self, thrust: float, roll: float = 0.0, pitch: float = 0.0, yaw: float = 0.0) -> None:
        """Ustawia silniki i wykonuje jeden krok symulacji (0.01 s)."""
        for name, v in (("thrust", thrust), ("roll", roll), ("pitch", pitch), ("yaw", yaw)):
            if v is None or not np.isfinite(v):
                raise ValueError(f"Sterowanie {name} = {v} - to nie jest poprawna liczba!")
        self._last_cmd = (thrust, roll, pitch, yaw)
        base = thrust / 4.0
        rotors = np.array(
            [
                base - roll + pitch - yaw,
                base + roll + pitch + yaw,
                base + roll - pitch - yaw,
                base - roll - pitch + yaw,
            ]
        )
        if self.wind_enabled:
            if self.rng.uniform() < 0.1:
                self._wind = self.rng.uniform(-0.5, 0.5, 4)
            rotors = rotors + self._wind
        self.data.ctrl[:4] = np.clip(rotors, 0.0, MAX_ROTOR_THRUST)

        self._apply_kicks()
        self._update_platform()
        mujoco.mj_step(self.model, self.data)
        if self.vertical_only:
            self._lock_to_vertical()
        self._check_mission()
        self._update_window()

    def _lock_to_vertical(self) -> None:
        """Zostawia tylko ruch w osi z: przywraca x, y i orientację ze startu, zeruje prędkości poza vz."""
        self.data.qpos[[0, 1, 3, 4, 5, 6]] = self._locked_qpos
        self.data.qvel[[0, 1, 3, 4, 5]] = 0.0
        mujoco.mj_forward(self.model, self.data)  # czujniki (IMU, GPS) zgodne z poprawionym stanem

    def _apply_kicks(self) -> None:
        if not self.kicks_enabled:
            return
        t = self.time
        if t >= self._next_kick:
            self._kick_torque = self.rng.normal(0, 1, 3) * np.array([0.25, 0.25, 0.08])
            self._kick_until = t + 0.15
            self._next_kick = t + self.rng.uniform(2.0, 3.5)
            self.data.xfrc_applied[self._drone_id, 3:6] += self._kick_torque
            self._kick_active = True
        elif self._kick_active and t >= self._kick_until:
            self.data.xfrc_applied[self._drone_id, 3:6] -= self._kick_torque
            self._kick_active = False

    def _check_mission(self) -> None:
        pos = self.data.body("x2").xpos
        # kolizje z bramkami
        touching = False
        for c in self.data.contact[: self.data.ncon]:
            g1, g2 = c.geom1, c.geom2
            if (g1 in self._drone_geoms and g2 in self._gate_geoms) or (g2 in self._drone_geoms and g1 in self._gate_geoms):
                touching = True
        if touching and not self._in_collision:
            self.collisions += 1
            print(f"[{self.time:5.2f} s] Uderzenie w bramkę!")
        self._in_collision = touching
        # wywrotka
        up = self.data.body("x2").xmat.reshape(3, 3)[:, 2]
        if up[2] < 0.2 and not self.crashed:
            self.crashed = True
            print(f"[{self.time:5.2f} s] Dron się przewrócił!")
        # przeloty przez bramki
        if self._next_gate < len(self.gates):
            gate = self.gates[self._next_gate]
            R = Rotation.from_euler("z", gate["yaw"], degrees=True).as_matrix()
            local = R.T @ (pos - gate["center"])
            if self._prev_local is not None and self._prev_local[0] > 0 >= local[0]:
                if abs(local[1]) < GATE_HALF_OPENING and abs(local[2]) < GATE_HALF_OPENING:
                    gate["passed"] = True
                    print(f"[{self.time:5.2f} s] Bramka {gate['index'] + 1} zaliczona!")
                    self._next_gate += 1
                    self._prev_local = None
                    return
            self._prev_local = local
        elif self.final_target is not None and not self.finished:
            if np.linalg.norm(pos - self.final_target) < 0.2:
                self.finished = True
                self.finish_time = self.time
                print(f"[{self.time:5.2f} s] META! Czas przelotu: {self.time:.2f} s, uderzenia: {self.collisions}")

    def _update_window(self) -> None:
        w = self.window
        if w.headless:
            self._targets = []
            return
        w.markers.clear()
        for pos, color, radius in self._targets:
            w.markers.sphere(pos, radius, color)
        self._targets = []
        roll, pitch, yaw = self.orientation()
        z = self.data.body("x2").xpos[2]
        w.texts = [("czas", f"{self.time:5.2f} s"), ("wysokość", f"{z:5.2f} m"), ("roll / pitch / yaw", f"{roll:5.1f} / {pitch:5.1f} / {yaw:6.1f}"), ("ciąg", f"{self._last_cmd[0]:5.2f} N")]
        if self.gates:
            passed = sum(g["passed"] for g in self.gates)
            w.texts.append(("bramki", f"{passed}/{len(self.gates)}"))
            if self.finished:
                w.texts.append(("META", f"{self.finish_time:.2f} s"))
        if self.collisions:
            w.texts.append(("uderzenia", str(self.collisions)))
        w.sync()

    # ------------------------------------------------------------------ koniec
    def finish(self) -> dict:
        """Zamyka okno, zapisuje wykres i wypisuje podsumowanie."""
        self.window.close()
        if self._renderer is not None:
            self._renderer.close()
        result = {
            "time": self.time,
            "crashed": self.crashed,
            "collisions": self.collisions,
            "gates_passed": sum(g["passed"] for g in self.gates),
            "finished": self.finished,
            "finish_time": self.finish_time,
        }
        print("-" * 50)
        print(f"Koniec symulacji po {self.time:.2f} s")
        if self.gates:
            print(f"Bramki: {result['gates_passed']}/{len(self.gates)}, uderzenia: {self.collisions}")
            print("Wynik: META osiągnięta w %.2f s" % self.finish_time if self.finished else "Wynik: nie dotarto do mety")
        if self.crashed:
            print("Uwaga: dron się przewrócił.")
        self.recorder.save(self.title, title=self.title)
        return result
