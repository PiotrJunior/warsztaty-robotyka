"""Ocena jakości regulacji (do konkursów). Tego pliku NIE musisz edytować."""

from __future__ import annotations

import numpy as np


def step_report(sim, figure: str, line: str, target: float, t_from: float, t_to: float, start: float | None = None, band: float = 0.05) -> dict:
    """Wypisuje parametry odpowiedzi na skok: przeregulowanie, czas ustalania, błąd ustalony."""
    pts = np.array(sim.recorder.data[figure][line])
    if len(pts) == 0:
        return {}
    mask = (pts[:, 0] >= t_from) & (pts[:, 0] < t_to)
    t, y = pts[mask, 0], pts[mask, 1]
    if len(t) == 0:
        return {}
    start = y[0] if start is None else start
    direction = np.sign(target - start) or 1.0
    overshoot = max(0.0, float(np.max(direction * (y - target))))
    outside = np.where(np.abs(y - target) > band)[0]
    if len(outside) == 0:
        settle = 0.0
    elif outside[-1] == len(y) - 1:
        settle = float("inf")
    else:
        settle = float(t[outside[-1] + 1] - t_from)
    last = y[t >= t[-1] - 1.0]
    steady_error = float(np.mean(last) - target)
    print(f"  Skok do {target:.2f} (od {t_from:.0f} s):  przeregulowanie {overshoot * 100:5.1f} cm | "
          f"czas ustalania (±{band * 100:.0f} cm) {settle:5.2f} s | błąd ustalony {steady_error * 100:+5.1f} cm")
    return {"overshoot": overshoot, "settling_time": settle, "steady_error": steady_error}
