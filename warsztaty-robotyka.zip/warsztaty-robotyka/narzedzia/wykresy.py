"""Zapisywanie przebiegów do wykresów PNG (po zakończeniu symulacji).

Tego pliku NIE musisz edytować.
"""

from __future__ import annotations

import os
import subprocess
import sys
from collections import defaultdict
from pathlib import Path

import numpy as np

RESULTS_DIR = Path(__file__).resolve().parent.parent / "wyniki"


class Recorder:
    """Zbiera przebiegi: recorder.add("wysokość z", t, cel=1.0, dron=0.93)."""

    def __init__(self):
        self.data: dict[str, dict[str, list[tuple[float, float]]]] = defaultdict(lambda: defaultdict(list))

    def add(self, fig_name: str, t: float, values: dict[str, float]) -> None:
        for name, value in values.items():
            self.data[fig_name][name].append((t, float(value)))

    def empty(self) -> bool:
        return not self.data

    def save(self, name: str, title: str = "", open_file: bool = True) -> Path | None:
        if self.empty():
            return None
        import matplotlib

        matplotlib.use("Agg")
        import matplotlib.pyplot as plt

        RESULTS_DIR.mkdir(exist_ok=True)
        n = len(self.data)
        fig, axes = plt.subplots(n, 1, figsize=(10, 2.8 * n), sharex=True, squeeze=False)
        colors: dict[str, str] = {}
        palette = plt.rcParams["axes.prop_cycle"].by_key()["color"]
        for ax, (fig_name, series) in zip(axes[:, 0], self.data.items()):
            for line_name, pts in series.items():
                arr = np.array(pts)
                color = colors.setdefault(line_name, palette[len(colors) % len(palette)])
                if line_name.startswith("pomiar"):
                    ax.plot(arr[:, 0], arr[:, 1], ".", label=line_name, color=color, markersize=4)
                else:
                    ax.plot(arr[:, 0], arr[:, 1], label=line_name, color=color, linewidth=1.5)
            ax.set_title(fig_name)
            ax.grid(alpha=0.3)
            ax.legend(loc="best")
        axes[-1, 0].set_xlabel("czas [s]")
        if title:
            fig.suptitle(title)
        fig.tight_layout()
        path = RESULTS_DIR / f"{name}.png"
        fig.savefig(path, dpi=110)
        plt.close(fig)
        print(f"Wykres zapisany: {path}")
        if open_file and "--nie-otwieraj" not in sys.argv:
            open_in_system(path)
        return path


def open_in_system(path: Path) -> None:
    try:
        if sys.platform == "darwin":
            subprocess.Popen(["open", str(path)])
        elif sys.platform.startswith("win"):
            os.startfile(str(path))  # type: ignore[attr-defined]
        else:
            subprocess.Popen(["xdg-open", str(path)], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except Exception:
        pass
