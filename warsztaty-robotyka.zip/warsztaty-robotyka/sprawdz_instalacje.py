"""Sprawdza, czy wszystko jest zainstalowane i działa.

    uv run python sprawdz_instalacje.py              (Linux / Windows)
    uv run mjpython sprawdz_instalacje.py            (macOS)
    ... --kamera                                     dodatkowo sprawdza kamerę laptopa
"""

import platform
import sys
import time

ok = True


def step(name, fn):
    global ok
    try:
        info = fn()
        print(f"  [OK]   {name}" + (f"  ({info})" if info else ""))
    except Exception as exc:  # noqa: BLE001
        ok = False
        print(f"  [BŁĄD] {name}: {type(exc).__name__}: {exc}")


print(f"System: {platform.system()} {platform.release()}, Python {sys.version.split()[0]}")


def imports():
    import cv2
    import matplotlib
    import mujoco
    import numpy
    import scipy

    return f"mujoco {mujoco.__version__}, opencv {cv2.__version__}, numpy {numpy.__version__}, scipy {scipy.__version__}, matplotlib {matplotlib.__version__}"


def aruco():
    import cv2
    import numpy as np

    from narzedzia.aruco import marker_image

    img = np.full((400, 400), 255, np.uint8)
    m = marker_image(7, 30)
    img[50 : 50 + m.shape[0], 50 : 50 + m.shape[1]] = m
    det = cv2.aruco.ArucoDetector(cv2.aruco.getPredefinedDictionary(cv2.aruco.DICT_4X4_50), cv2.aruco.DetectorParameters())
    _, ids, _ = det.detectMarkers(img)
    assert ids is not None and int(np.ravel(ids)[0]) == 7, "nie wykryto markera"
    return "wykryto marker ID 7"


def render():
    from narzedzia import DroneSim

    sim = DroneSim(scene="markery", camera="down_camera", gps=False, start_pos=(0, 0, 1.0), headless=True)
    img = sim.camera_image()
    sim._renderer.close()
    assert img is not None and img.mean() > 5, "pusty obraz"
    return f"obraz {img.shape[1]}x{img.shape[0]}"


def viewer():
    import mujoco

    from narzedzia.okno import open_viewer

    m = mujoco.MjModel.from_xml_string("<mujoco><worldbody><light pos='0 0 3'/><geom type='plane' size='1 1 .1'/><body pos='0 0 1'><freejoint/><geom type='sphere' size='.1' rgba='1 .3 .3 1'/></body></worldbody></mujoco>")
    d = mujoco.MjData(m)
    h = open_viewer(m, d)
    t0 = time.time()
    while h.is_running() and time.time() - t0 < 2.0:
        mujoco.mj_step(m, d)
        h.sync()
        time.sleep(m.opt.timestep)
    h.close()
    return "okno otwarte na 2 s"


def camera():
    import cv2

    cap = cv2.VideoCapture(0)
    ok_, frame = cap.read()
    cap.release()
    assert ok_ and frame is not None, "nie mogę odczytać obrazu z kamery 0"
    return f"klatka {frame.shape[1]}x{frame.shape[0]}"


step("biblioteki", imports)
step("OpenCV ArUco", aruco)
step("renderowanie kamery w MuJoCo", render)
if "--bez-okna" not in sys.argv:
    step("okno symulacji (viewer)", viewer)
if "--kamera" in sys.argv:
    step("kamera laptopa", camera)

print()
print("Wszystko gotowe! :)" if ok else "Coś nie działa - pokaż ten wynik prowadzącemu.")
sys.exit(0 if ok else 1)
