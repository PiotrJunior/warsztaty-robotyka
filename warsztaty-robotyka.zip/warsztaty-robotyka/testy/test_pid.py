"""Testy klasy PID.   Uruchom:  uv run python testy/test_pid.py"""

from _sprawdzarka import check, summary

from moj_kod.pid import PID

print("Test regulatora PID (moj_kod/pid.py)")


def only_p():
    pid = PID(kp=2.0, ki=0.0, kd=0.0, dt=0.1)
    return abs(pid.update(1.0, 0.25) - 1.5) < 1e-9


def only_i():
    pid = PID(kp=0.0, ki=1.0, kd=0.0, dt=0.1)
    outs = [pid.update(1.0, 0.0) for _ in range(3)]  # całka błędu 1.0 przez 0.1 s, 0.2 s, 0.3 s
    return all(abs(o - e) < 1e-9 for o, e in zip(outs, [0.1, 0.2, 0.3]))


def d_first_call_zero():
    pid = PID(kp=0.0, ki=0.0, kd=1.0, dt=0.1)
    return abs(pid.update(1.0, 0.0)) < 1e-9


def only_d():
    pid = PID(kp=0.0, ki=0.0, kd=1.0, dt=0.1)
    pid.update(1.0, 0.0)  # błąd 1.0
    out = pid.update(1.0, 0.5)  # błąd 0.5 -> zmiana -0.5 w 0.1 s -> pochodna -5
    return abs(out - (-5.0)) < 1e-9


def full_pid():
    pid = PID(kp=1.0, ki=2.0, kd=0.5, dt=0.1)
    a = pid.update(2.0, 1.0)  # e=1: P=1, I=2*0.1=0.2, D=0
    b = pid.update(2.0, 1.5)  # e=0.5: P=0.5, I=2*(0.1+0.05)=0.3, D=0.5*(-0.5/0.1)=-2.5
    return abs(a - 1.2) < 1e-9 and abs(b - (0.5 + 0.3 - 2.5)) < 1e-9


def limits():
    pid = PID(kp=10.0, ki=0.0, kd=0.0, dt=0.1, output_limits=(-1.0, 2.0))
    return pid.update(5.0, 0.0) == 2.0 and pid.update(-5.0, 0.0) == -1.0 and abs(pid.update(0.1, 0.0) - 1.0) < 1e-9


def no_limits():
    pid = PID(kp=10.0, ki=0.0, kd=0.0, dt=0.1)
    return abs(pid.update(100.0, 0.0) - 1000.0) < 1e-9


def reset():
    pid = PID(kp=0.0, ki=1.0, kd=1.0, dt=0.1)
    pid.update(1.0, 0.0)
    pid.update(1.0, 0.0)
    pid.reset()
    return abs(pid.update(1.0, 0.0) - 0.1) < 1e-9


check("człon P:  kp * błąd", only_p, "błąd = target - measurement, P = kp * błąd")
check("człon I:  ki * suma(błąd * dt)", only_i, "dodawaj błąd * dt do zmiennej self.integral przy każdym wywołaniu")
check("człon D w pierwszym wywołaniu = 0", d_first_call_zero, "nie ma jeszcze poprzedniego błędu - pochodna to 0 (np. self.prev_error = None)")
check("człon D:  kd * (błąd - poprzedni błąd) / dt", only_d, "zapamiętaj błąd w self.prev_error na koniec update()")
check("P + I + D razem", full_pid)
check("ograniczenie wyjścia (output_limits)", limits, "jeśli wynik > max, zwróć max; jeśli < min, zwróć min")
check("brak ograniczeń, gdy output_limits = (None, None)", no_limits, "sprawdzaj 'if high is not None and ...'")
check("reset() zeruje pamięć regulatora", reset)
summary()
