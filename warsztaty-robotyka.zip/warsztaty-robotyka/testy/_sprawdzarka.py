"""Mini-sprawdzarka do testów (bez pytest)."""

import sys
import traceback

_failed = 0


def check(name: str, condition_fn, hint: str = "") -> None:
    global _failed
    try:
        ok = bool(condition_fn())
        err = ""
    except Exception as exc:  # noqa: BLE001
        ok = False
        err = f"{type(exc).__name__}: {exc}"
        if "--debug" in sys.argv:
            traceback.print_exc()
    if ok:
        print(f"  [OK]   {name}")
    else:
        _failed += 1
        print(f"  [BŁĄD] {name}")
        if err:
            print(f"         wyjątek: {err}")
        if hint:
            print(f"         wskazówka: {hint}")


def summary() -> None:
    print()
    if _failed == 0:
        print("Wszystkie testy przeszły! :)")
    else:
        print(f"Nie przeszło testów: {_failed}. Popraw kod i uruchom ponownie.")
        sys.exit(1)
