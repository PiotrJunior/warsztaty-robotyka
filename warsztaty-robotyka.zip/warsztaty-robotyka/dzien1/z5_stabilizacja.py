"""Zadanie 1.5 - Stabilizacja orientacji (roll, pitch, yaw).

Uruchom:   uv run python dzien1/z5_stabilizacja.py      (macOS: uv run mjpython dzien1/z5_stabilizacja.py)

Edytujesz:  moj_kod/kontroler.py  (pid_roll, pid_pitch, pid_yaw oraz metoda attitude)

Co jakiś czas ktoś "kopie" drona (losowy moment obrotowy). Możesz też kopnąć go sam:
dwuklik na dronie, potem Ctrl + przeciąganie myszą.

Kroki:
  1. Uruchom bez stabilizacji (wzmocnienia = 0). Co się dzieje po kopnięciu?
  2. Dobierz kp dla roll i pitch. Potem dodaj kd. Ile wynosi największe przechylenie?
  3. Kopnięcia obracają też drona wokół osi pionowej. Dobierz pid_yaw, żeby yaw wracał do 0.
  *  Wiatr: zmień wind=False na wind=True.
  ** Dron powoli odlatuje w bok, mimo że jest poziomo. Dlaczego? (Rozwiążemy to jutro!)
"""

from moj_kod.kontroler import DroneController
from narzedzia import DroneSim

sim = DroneSim(scene="pusta", duration=16, start_pos=(0, 0, 0.1), kicks=True, wind=False)
ctrl = DroneController(sim.dt)

TARGET_Z = 1.0
max_tilt = 0.0

while sim.running():
    z = sim.position()[2]
    roll, pitch, yaw = sim.orientation()

    thrust = ctrl.altitude(TARGET_Z, z, roll, pitch)
    roll_cmd, pitch_cmd, yaw_cmd = ctrl.attitude(0.0, 0.0, roll, pitch, yaw)
    sim.step(thrust, roll_cmd, pitch_cmd, yaw_cmd)

    if sim.time > 2.0:
        max_tilt = max(max_tilt, abs(roll), abs(pitch))
    sim.log("roll i pitch [stopnie]", roll=roll, pitch=pitch)
    sim.log("yaw [stopnie]", cel=0.0, yaw=yaw)
    sim.log("wysokość z [m]", cel=TARGET_Z, dron=z)

sim.finish()
print(f"Największe przechylenie po starcie: {max_tilt:.1f}°" + ("   (dron się przewrócił!)" if sim.crashed else ""))
