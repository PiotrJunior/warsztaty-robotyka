"""Zadanie 1.4 - Utrzymaj wysokość (regulator PID na osi z).

Uruchom:   uv run python dzien1/z4_wysokosc.py         (macOS: uv run mjpython dzien1/z4_wysokosc.py)
Szybko, bez okna:  uv run python dzien1/z4_wysokosc.py --bez-okna

Edytujesz:  moj_kod/pid.py  (klasa PID)  i  moj_kod/kontroler.py  (pid_z oraz metoda altitude)

Kroki:
  1. Tylko P (ki = kd = 0). Czy dron w ogóle wystartuje? Zwiększaj kp. Co widzisz?
  2. Dodaj D. Co się stało z oscylacjami?
  3. Dron wisi, ale za nisko? Dodaj I. Dlaczego to pomaga?
  *  Zamiast czekać na całkę: ciąg potrzebny do zawiśnięcia to masa * g. Dodaj go w altitude().
  ** Konkurs: najmniejsze przeregulowanie i najkrótszy czas ustalania (wypisze się na końcu).
"""

from moj_kod.kontroler import DroneController
from narzedzia import DroneSim
from narzedzia.ocena import step_report

# (od której sekundy, zadana wysokość [m])
TARGETS = [(0.0, 1.0), (7.0, 1.5), (12.0, 0.5)]

sim = DroneSim(scene="pusta", duration=17, start_pos=(0, 0, 0.1))
ctrl = DroneController(sim.dt)

while sim.running():
    target_z = [z for t, z in TARGETS if sim.time >= t][-1]

    z = sim.position()[2]
    roll, pitch, yaw = sim.orientation()

    thrust = ctrl.altitude(target_z, z, roll, pitch)
    sim.step(thrust)  # roll = pitch = yaw = 0 - na razie nie stabilizujemy obrotu

    sim.show_target((0, 0, target_z))
    sim.log("wysokość z [m]", cel=target_z, dron=z)
    sim.log("ciąg [N]", ciąg=thrust, zawis=sim.mass * 9.81)

sim.finish()
print("Wyniki:")
for (t0, z0), (t1, _) in zip(TARGETS, TARGETS[1:] + [(sim.duration, None)]):
    step_report(sim, "wysokość z [m]", "dron", target=z0, t_from=t0, t_to=t1)
