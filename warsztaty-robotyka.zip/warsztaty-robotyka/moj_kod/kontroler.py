"""Sterownik drona.

DZIEŃ 1:  zadanie 1.4 - wysokość (altitude), zadanie 1.5 - orientacja (attitude)
DZIEŃ 2:  zadanie 2.1 - pozycja (position)
DZIEŃ 3:  ten sam sterownik, tylko pozycja przychodzi z kamery zamiast z GPS!

Schemat (kaskada regulatorów):

    cel x,y ──► [PID x, PID y] ──► zadany roll/pitch ──► [PID roll, PID pitch] ──► silniki
    cel z   ──► [PID z] ─────────────────────────────────────────────────────────► ciąg
    yaw = 0 ──► [PID yaw] ───────────────────────────────────────────────────────► silniki

Yaw (obrót wokół osi pionowej) trzymamy ZAWSZE na 0. Dzięki temu "przód" drona zawsze patrzy
w tę samą stronę i osie drona pokrywają się z osiami świata: pitch pcha w x, roll w y.
"""

import math

from moj_kod.pid import PID

DRONE_MASS = 1.325  # [kg]
GRAVITY = 9.81  # [m/s^2]
MAX_TILT = 20.0  # [stopnie] maksymalne przechylenie, o które prosi regulator pozycji


class DroneController:
    def __init__(self, dt: float):
        # ---------------------------------------------------------------- Zadanie 1.4
        # Regulator wysokości: błąd wysokości [m] -> ciąg [N]
        # TODO: TWÓJ KOD TUTAJ
        self.pid_z = PID(kp=0.0, ki=0.0, kd=0.0, dt=dt, output_limits=(-20, 20))

        # ---------------------------------------------------------------- Zadanie 1.5
        # Regulatory orientacji: błąd kąta [stopnie] -> różnica ciągu śmigieł [N]
        # Limity są małe celowo: w zawisie każde śmigło daje ~3.25 N, a 3.25 - 1.2 - 1.2 - 0.6 > 0,
        # więc żadne śmigło nie musi "kręcić się do tyłu" (czego nie potrafi).
        # TODO: TWÓJ KOD TUTAJ
        self.pid_roll = PID(kp=0.0, ki=0.0, kd=0.0, dt=dt, output_limits=(-1.2, 1.2))
        self.pid_pitch = PID(kp=0.0, ki=0.0, kd=0.0, dt=dt, output_limits=(-1.2, 1.2))
        self.pid_yaw = PID(kp=0.0, ki=0.0, kd=0.0, dt=dt, output_limits=(-0.6, 0.6))

        # ---------------------------------------------------------------- Zadanie 2.1
        # Regulatory pozycji: błąd pozycji [m] -> zadany kąt przechylenia [stopnie]
        # TODO: TWÓJ KOD TUTAJ
        self.pid_x = PID(kp=0.0, ki=0.0, kd=0.0, dt=dt, output_limits=(-MAX_TILT, MAX_TILT))
        self.pid_y = PID(kp=0.0, ki=0.0, kd=0.0, dt=dt, output_limits=(-MAX_TILT, MAX_TILT))

    # ==================================================================== Zadanie 1.4
    def altitude(self, target_z: float, z: float, roll: float = 0.0, pitch: float = 0.0) -> float:
        """Zwraca całkowity ciąg [N], który utrzyma drona na wysokości target_z.

        Wskazówki:
          - zacznij od samego regulatora: return self.pid_z.update(target_z, z)
          - (*) ciąg potrzebny do zawiśnięcia to masa * g - dodaj go "z góry" (feedforward)
          - (**) przechylony dron "pcha" częściowo w bok - podziel ciąg przez cos(roll)*cos(pitch)
        """
        # TODO: TWÓJ KOD TUTAJ
        return 0.0

    # ==================================================================== Zadanie 1.5
    def attitude(self, target_roll, target_pitch, roll, pitch, yaw):
        """Zwraca (roll_cmd, pitch_cmd, yaw_cmd) - różnice ciągu, które ustawią drona pod zadanymi kątami.

        Cel dla yaw to zawsze 0 (dron się nie obraca).
        """
        # TODO: TWÓJ KOD TUTAJ
        return 0.0, 0.0, 0.0

    # ==================================================================== Zadanie 2.1
    def position(self, target_pos, pos):
        """Zwraca (target_roll, target_pitch) [stopnie], które popchną drona w stronę target_pos.

        Pamiętaj (yaw = 0):
            dodatni pitch -> dron leci w stronę +x
            dodatni roll  -> dron leci w stronę -y   (uwaga na znak!)
        """
        # TODO: TWÓJ KOD TUTAJ
        return 0.0, 0.0

    # ==================================================================== wszystko razem
    def control(self, target_pos, pos, orientation):
        """Pełna kaskada: cel (x, y, z) -> komendy dla sim.step(). Tego nie musisz zmieniać."""
        roll, pitch, yaw = orientation
        target_roll, target_pitch = self.position(target_pos, pos)
        thrust = self.altitude(target_pos[2], pos[2], roll, pitch)
        roll_cmd, pitch_cmd, yaw_cmd = self.attitude(target_roll, target_pitch, roll, pitch, yaw)
        return thrust, roll_cmd, pitch_cmd, yaw_cmd
