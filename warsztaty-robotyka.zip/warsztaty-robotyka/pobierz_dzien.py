"""Dodaje do folderu warsztatów zadania na kolejny dzień.

    uv run python pobierz_dzien.py 2                  # pobiera dzien2.zip z internetu
    uv run python pobierz_dzien.py 2 ŚCIEŻKA_LUB_ADRES  # z pliku (np. z pendrive'a) albo z innego adresu

Skrypt TYLKO DODAJE nowe pliki. Plików, które już masz (np. Twojego kodu w moj_kod/), nie nadpisuje.
"""

from __future__ import annotations

import io
import shutil
import subprocess
import sys
import tempfile
import urllib.request
import zipfile
from pathlib import Path, PurePosixPath

# Skąd pobierać paczki z kolejnymi dniami ({n} = numer dnia). Ustawia prowadzący.
ADRES = "https://raw.githubusercontent.com/PiotrJunior/warsztaty-robotyka/main/dzien{n}.zip"

ROOT = Path(__file__).resolve().parent
ZAWSZE_NADPISZ = {"README.md"}  # tego pliku nikt nie edytuje, a w nowej wersji są nowe zadania


def wczytaj_zrodlo(n: int, zrodlo: str | None) -> dict[str, bytes]:
    if zrodlo is None:
        for kandydat in [ROOT / f"dzien{n}.zip", Path.home() / "Downloads" / f"dzien{n}.zip", Path.home() / "Pobrane" / f"dzien{n}.zip"]:
            if kandydat.exists():
                print(f"Używam pliku {kandydat}")
                return z_zipa(kandydat.read_bytes())
        if not ADRES:
            sys.exit(f"Podaj, skąd wziąć paczkę, np.:  uv run python pobierz_dzien.py {n} ŚCIEŻKA/dzien{n}.zip")
        zrodlo = ADRES.format(n=n)
    if zrodlo.startswith(("http://", "https://")):
        return z_zipa(pobierz(zrodlo))
    sciezka = Path(zrodlo).expanduser()
    if sciezka.is_dir():  # np. Safari sam rozpakował zip
        return {p.relative_to(sciezka).as_posix(): p.read_bytes() for p in sciezka.rglob("*") if p.is_file()}
    if not sciezka.exists():
        sys.exit(f"Nie ma pliku: {sciezka}")
    return z_zipa(sciezka.read_bytes())


def pobierz(adres: str) -> bytes:
    print(f"Pobieram {adres} ...")
    try:
        with urllib.request.urlopen(adres, timeout=30) as r:
            return r.read()
    except Exception as exc:  # noqa: BLE001 - spróbujmy jeszcze curl (inne certyfikaty / proxy)
        if shutil.which("curl"):
            with tempfile.TemporaryDirectory() as tmp:
                cel = Path(tmp) / "paczka.zip"
                if subprocess.run(["curl", "-fsSL", "-o", str(cel), adres]).returncode == 0:
                    return cel.read_bytes()
        sys.exit(f"Nie udało się pobrać ({exc}).\nPobierz plik w przeglądarce i podaj jego ścieżkę:\n"
                 f"  uv run python pobierz_dzien.py N ŚCIEŻKA/do/pliku.zip")


def z_zipa(dane: bytes) -> dict[str, bytes]:
    try:
        zf = zipfile.ZipFile(io.BytesIO(dane))
    except zipfile.BadZipFile:
        sys.exit("To nie jest poprawny plik .zip (może pobrał się tylko w części?).")
    return {i.filename: zf.read(i) for i in zf.infolist() if not i.is_dir()}


def normalizuj(pliki: dict[str, bytes], n: int) -> dict[str, bytes]:
    """Usuwa śmieci i ewentualny wspólny folder na górze (gdy ktoś spakował zip jeszcze raz)."""
    pliki = {k: v for k, v in pliki.items() if "__MACOSX" not in k and not k.endswith(".DS_Store")}
    while pliki and not any(k.startswith(f"dzien{n}/") for k in pliki):
        gora = {k.split("/", 1)[0] for k in pliki}
        if len(gora) != 1 or all("/" not in k for k in pliki):
            break
        pliki = {k.split("/", 1)[1]: v for k, v in pliki.items()}
    if not any(k.startswith(f"dzien{n}/") for k in pliki):
        sys.exit(f"W tej paczce nie ma folderu dzien{n}/ - to chyba nie ta paczka.")
    for k in pliki:
        p = PurePosixPath(k)
        if p.is_absolute() or ".." in p.parts:
            sys.exit(f"Podejrzana ścieżka w paczce: {k}")
    return pliki


def main() -> None:
    if len(sys.argv) < 2 or not sys.argv[1].isdigit():
        sys.exit(__doc__)
    n = int(sys.argv[1])
    pliki = normalizuj(wczytaj_zrodlo(n, sys.argv[2] if len(sys.argv) > 2 else None), n)
    dodane, pominiete = [], []
    for nazwa, dane in sorted(pliki.items()):
        cel = ROOT / nazwa
        if cel.exists():
            if cel.read_bytes() == dane:
                continue
            if nazwa not in ZAWSZE_NADPISZ:
                pominiete.append(nazwa)
                continue
        cel.parent.mkdir(parents=True, exist_ok=True)
        cel.write_bytes(dane)
        dodane.append(nazwa)
    for nazwa in dodane:
        print(f"  + {nazwa}")
    for nazwa in pominiete:
        print(f"  = {nazwa}  (już masz ten plik - zostawiam Twoją wersję)")
    print(f"\nGotowe: dodano {len(dodane)} plików. Zadania dnia {n} są w folderze dzien{n}/ - opis w README.md.")


if __name__ == "__main__":
    main()
