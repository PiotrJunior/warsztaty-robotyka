# Robotyka i symulacje robotów

Warsztaty: projektujemy i testujemy roboty w symulatorze fizyki **MuJoCo**.
Dron nauczy się latać dzięki regulatorom **PID**, chwytak zbuduje wieżę z klocków, rozpoznając markery
**ArUco** w obrazie z kamery (**OpenCV**), a na koniec dron poleci bez GPS, korzystając tylko z kamery
i **filtru Kalmana**.

## 1. Instalacja (przed warsztatami!)

Potrzebujesz tylko programu **uv** - on sam pobierze Pythona i wszystkie biblioteki.

**Linux / macOS** (w terminalu):
```bash
curl -LsSf https://astral.sh/uv/install.sh | sh
```
Jeśli nie masz `curl` (np. Ubuntu), użyj `wget`:
```bash
wget -qO- https://astral.sh/uv/install.sh | sh
```

**Windows** (w PowerShell):
```powershell
powershell -ExecutionPolicy ByPass -c "irm https://astral.sh/uv/install.ps1 | iex"
```

Zamknij i otwórz terminal ponownie. Potem rozpakuj paczkę z warsztatami, wejdź do jej folderu i wpisz:
```bash
uv sync
```

Sprawdź, czy wszystko działa (powinno pokazać się na chwilę okno z kulką):

| System            | Polecenie                                      |
|-------------------|------------------------------------------------|
| Linux, Windows    | `uv run python sprawdz_instalacje.py --kamera` |
| macOS             | `uv run mjpython sprawdz_instalacje.py --kamera` |

Na końcu powinno być: **Wszystko gotowe! :)**

## 2. Jak uruchamiać zadania

| System            | Zadania z oknem symulacji                 |
|-------------------|-------------------------------------------|
| Linux, Windows    | `uv run python dzien1/z4_wysokosc.py`     |
| macOS             | `uv run mjpython dzien1/z4_wysokosc.py`   |

- `--bez-okna` - symulacja bez okna, dużo szybciej (np. do strojenia regulatora); na końcu otworzy się wykres.
- Po każdym uruchomieniu wykres zapisuje się w folderze `wyniki/`.
- Pliki `.xml` (budowanie modeli) otwierasz w przeglądarce modeli - działa tak samo na każdym systemie:
  `uv run python -m mujoco.viewer --mjcf=dzien1/z1_piaskownica.xml`

**Okno symulacji:** lewy przycisk myszy - obrót kamery, prawy - przesuwanie, kółko - przybliżenie,
`Esc` - wolna kamera (gdy kamera śledzi drona), `[` i `]` - zmiana kamery.
Dwuklik na obiekcie, a potem `Ctrl` + przeciąganie myszą - pchnięcie obiektu.

## 3. Co jest w środku

```
moj_kod/        <- TU PISZESZ: pid.py, kontroler.py (a w kolejnych dniach kolejne pliki)
dzien1/         zadania z dnia 1 (MuJoCo, PID)
dzien2/         zadania z dnia 2 (pojawią się rano dnia 2)
dzien3/         zadania z dnia 3 (pojawią się rano dnia 3)
testy/          testy Twojego kodu, np.: uv run python testy/test_pid.py
narzedzia/      symulatory i pomocnicze funkcje - nie musisz ich zmieniać (ale możesz czytać!)
assets/         modele 3D (dron Skydio X2, chwytak)
materialy/      markery ArUco do wydrukowania
wyniki/         tu zapisują się wykresy
```

Miejsca do uzupełnienia są oznaczone `# TODO: TWÓJ KOD TUTAJ`. Opis każdego zadania jest na górze jego pliku.

## 4. Zadania

**Dzień 1 - MuJoCo i PID**
| | Zadanie | Plik |
|---|---|---|
| 1.1 | Piaskownica fizyki | `dzien1/z1_piaskownica.xml` |
| 1.2 | Ramię robota | `dzien1/z2_ramie.xml` |
| 1.3 | Zbuduj latający chwytak | `dzien1/z3_chwytak.xml` |
| ★ | Wyzwanie pilota: utrzymaj drona suwakami silników | `uv run python -m mujoco.viewer --mjcf=assets/scena_dron.xml` |
| 1.4 | Regulator PID wysokości | `moj_kod/pid.py`, `moj_kod/kontroler.py`, uruchom `dzien1/z4_wysokosc.py` |
| 1.5 | Stabilizacja orientacji | `moj_kod/kontroler.py`, uruchom `dzien1/z5_stabilizacja.py` |



**Zadania na kolejny dzień** dostaniesz rano. Wpisz wtedy w folderze warsztatów:
```bash
uv run python pobierz_dzien.py 2
```
(a dnia 3: `... pobierz_dzien.py 3`). Skrypt **tylko dodaje nowe pliki** - Twojego kodu nie ruszy.

## 5. Gdy coś nie działa

- **macOS: „okno symulacji wymaga uruchomienia przez mjpython”** - użyj `uv run mjpython ...` zamiast `uv run python ...`.
- **macOS: kamera laptopa nie działa** - Ustawienia systemowe → Prywatność i ochrona → Kamera → zezwól dla Terminala.
- **Windows/Linux: zła kamera** - zmień `CAMERA_INDEX = 0` na `1` w `dzien2/z3_kamera_laptopa.py`.
- **Ubuntu/Linux: okno symulacji się wysypuje z `GLib-GIO-ERROR ... antialiasing`** - wpisz raz
  `echo 'export PYGLFW_LIBRARY_VARIANT=x11' >> ~/.bashrc` i otwórz terminal na nowo.
- **Linux: błąd OpenGL przy renderowaniu kamery** - spróbuj `MUJOCO_GL=egl uv run python ...`.
- **Symulacja działa wolno** - uruchom z `--bez-okna` i oglądaj wykres.

Model drona Skydio X2 pochodzi z [MuJoCo Menagerie](https://github.com/google-deepmind/mujoco_menagerie) (licencja Apache-2.0, `assets/x2/LICENSE`).
Zadania są inspirowane kursem *Robot Control* (MIMUW 2025/26).
